import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:smart_assistant_app/core/helpers/dailog/show_dialog.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import '../../../view_model/syllabus/syllabus_cubit.dart';
import '../../../view_model/syllabus/syllabus_state.dart';
import '../widget/syllabus_screen/list_view_syllabus.dart';

class ListViewSyllabusBlocBuilder extends StatelessWidget {
  final UserModel userModel;
  final List<int> courseIds;
  const ListViewSyllabusBlocBuilder({super.key , required this.userModel, required this.courseIds});

  @override
  Widget build(BuildContext context) {
   return BlocConsumer<SyllabusCubit , SyllabusState>(builder: (context , state){
       if(state is SyllabusLoaded ){
          return ListViewSyllabus(
            courseIds: courseIds,
            userModel: userModel,
           courseWithSyllabiModel: state.coursesWithSyllabi,
          );
       }
       return Skeletonizer(child:  ListViewSyllabus(userModel: userModel, courseIds: courseIds,));
    }, listener: (context, state) {
      if(state is SyllabusError){
        DialogHelper.errorMessage(context, state.message);
      }
    },
    );
  }
}