import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/view_model/syllabus/syllabus_cubit.dart';
import 'package:smart_assistant_app/view_model/syllabus/syllabus_state.dart';
import '../widget/syllabus_screen/conainer_upper_bar_syllabus.dart';


class ConainerUpperBarSyllabusBlocBuilder extends StatelessWidget {
  final List<CurrentCourse> currentCourse;
  const ConainerUpperBarSyllabusBlocBuilder({super.key , required this.currentCourse});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SyllabusCubit , SyllabusState>(builder: (context , state){
       if(state is SyllabusLoaded ){
           int sum = 0;
           for(int i = 0 ;  i< state.coursesWithSyllabi.length  ; i++){
             sum += state.coursesWithSyllabi[i].syllabi.length;
           }
          return ConainerUpperBarSyllabus(countCourse: currentCourse.length , countSyllabus: sum,);
       }
       return const Skeletonizer(child:  ConainerUpperBarSyllabus());
    });
  }
}