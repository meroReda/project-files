import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/server/end_point.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_circle_icon.dart';
import 'package:smart_assistant_app/model/syllabus_model.dart';
import 'package:url_launcher/url_launcher.dart';

class CardSyllabusCourseDeleteCheck extends StatelessWidget {
  final SyllabusModel syllabusModel;
  const CardSyllabusCourseDeleteCheck({super.key, required this.syllabusModel});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 6,
      child: Padding(
        padding: PaddingApp.ver15,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  const CustomCircleIcon(
                    backGroundColor: Color(0xFFf9fafb),
                    icon: Icons.picture_as_pdf_outlined,
                    iconColor: Colors.red,
                  ),
                  getWidth(5),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          syllabusModel.fileName,
                          style: TextStyleApp.font9Black,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.file_copy, size: 10),
                            getWidth(3),
                            Text(
                              '${(syllabusModel.fileSize / 1048576).toStringAsFixed(2)} MB',
                              style: TextStyleApp.font7Grey,
                            ),
                            getWidth(5),
                            const Icon(Icons.date_range, size: 10),
                            getWidth(3),
                            Text(
                              syllabusModel.uploadedAt.toString(),
                              style: TextStyleApp.font7Grey,
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            getWidth(5),
            Row(
              children: [
                GestureDetector(
                  onTap: () => _openPdfDirectly(context),
                  child: const CustomCircleIcon(
                    size: 30,
                    backGroundColor: Color(0xFFf9fafb),
                    icon: Icons.remove_red_eye_outlined,
                    iconColor: Colors.green,
                  ),
                ),
                getWidth(10),
                const CustomCircleIcon(
                  size: 30,
                  backGroundColor: Color(0xFFf9fafb),
                  icon: Icons.delete,
                  iconColor: Colors.red,
                ),
                getWidth(3),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openPdfDirectly(BuildContext context) async {
    try {
      String pdfUrl = '${EndPoint.baseUrl}${syllabusModel.filePath}';
      pdfUrl = pdfUrl.trim();
      pdfUrl = pdfUrl.replaceAll(' ', '%20');
      await launchUrl(
        Uri.parse(pdfUrl),
        mode: LaunchMode.externalApplication,
      );
      
    } catch (e) {
      _showPdfOptionsDialog(context);
    }
  }

  void _showPdfOptionsDialog(BuildContext context) {
    String pdfUrl = '${EndPoint.baseUrl}${syllabusModel.filePath}';
    pdfUrl = pdfUrl.replaceAll(' ', '%20').trim();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('فتح ملف PDF'),
        content: const Text('اختر طريقة فتح ملف PDF:'),
        actions: [
          // خيار 1: فتح في WebView
          TextButton.icon(
            onPressed: () {
              Navigator.pop(context);
              _openInSimpleWebView(context, pdfUrl);
            },
            icon: const Icon(Icons.web),
            label: const Text('فتح داخل التطبيق'),
          ),
          
          // خيار 2: فتح في متصفح خارجي
          TextButton.icon(
            onPressed: () {
              Navigator.pop(context);
              _launchInBrowser(pdfUrl);
            },
            icon: const Icon(Icons.open_in_browser),
            label: const Text('فتح في المتصفح'),
          ),
          
          // خيار 3: نسخ الرابط
          TextButton.icon(
            onPressed: () {
              Navigator.pop(context);
              _copyToClipboard(context, pdfUrl);
            },
            icon: const Icon(Icons.copy),
            label: const Text('نسخ الرابط'),
          ),
          
          // خيار 4: إلغاء
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
        ],
      ),
    );
  }

  void _openInSimpleWebView(BuildContext context, String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: Text(syllabusModel.fileName)),
          body: WebViewSimple(url: url),
        ),
      ),
    );
  }

  Future<void> _launchInBrowser(String url) async {
    await launchUrl(Uri.parse(url));
  }

  void _copyToClipboard(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نسخ الرابط إلى الحافظة')),
    );
  }
}

// Widget بسيط لعرض WebView
class WebViewSimple extends StatefulWidget {
  final String url;
  const WebViewSimple({super.key, required this.url});

  @override
  State<WebViewSimple> createState() => _WebViewSimpleState();
}

class _WebViewSimpleState extends State<WebViewSimple> {
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('قم بتثبيت webview_flutter لعرض PDF'),
    );
  }
}