import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:smart_assistant_app/core/helpers/dailog/show_dialog.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/router/router_model.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/theme/colors_app.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/button_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_circle_icon.dart';
import 'package:smart_assistant_app/model/syllabus_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/syllabus/syllabus_cubit.dart';

import '../../../../view_model/syllabus/syllabus_state.dart';

class CardSyllabusCourse extends StatefulWidget {
  final CourseWithSyllabiModel? courseWithSyllabiModel;
  final UserModel userModel;
  final List<int> courseIds;
  const CardSyllabusCourse(
      {super.key,
      this.courseWithSyllabiModel,
      required this.userModel,
      required this.courseIds});

  @override
  State<CardSyllabusCourse> createState() => _CardSyllabusCourseState();
}

class _CardSyllabusCourseState extends State<CardSyllabusCourse> {
  PlatformFile? _selectedFile;
  TextEditingController fileNameController = TextEditingController();

  Future<void> _pickFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        allowMultiple: false,
        withData: true,
      );

      if (result != null && result.files.isNotEmpty) {
        PlatformFile file = result.files.first;

        // التحقق من وجود بيانات الملف
        if (file.bytes == null || file.bytes!.isEmpty) {
          DialogHelper.errorMessage(context, 'الملف فارغ أو تالف');
          return;
        }

        setState(() {
          _selectedFile = file;
          fileNameController.text = _selectedFile!.name;
        });
      }
    } catch (e) {
      DialogHelper.errorMessage(context, 'خطأ في اختيار الملف: $e');
    }
  }

  Future<void> _uploadSyllabus(BuildContext context) async {
    if (fileNameController.text.isEmpty) {
      DialogHelper.errorMessage(context, 'الرجاء إدخال اسم الملف');
      return;
    }
    if (_selectedFile == null) {
      DialogHelper.errorMessage(context, 'الرجاء اختيار ملف PDF');
      return;
    }
    final cubit = BlocProvider.of<SyllabusCubit>(context);
    // تحقق إذا كان الملف PDF
    if (!_selectedFile!.name.toLowerCase().endsWith('.pdf')) {
      DialogHelper.errorMessage(context, 'الرجاء اختيار ملف PDF فقط');
      return;
    }
    // تحقق من حجم الملف (مثال: 50MB كحد أقصى)
    if (_selectedFile!.size > 50 * 1024 * 1024) {
      DialogHelper.errorMessage(
          context, 'حجم الملف كبير جداً (الحد الأقصى 50MB)');
      return;
    }

    await cubit.uploadSyllabus(
      courseIds: widget.courseIds,
      userId: widget.userModel.userID,
      courseId: widget.courseWithSyllabiModel!.courseId,
      file: _selectedFile!,
      syllabusName: fileNameController.text,
      isPublic: false,
    );
  }

  void _openUploadDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return BlocConsumer<SyllabusCubit, SyllabusState>(
              listener: (context, state) {
                try {
                  if (state is SyllabusLoaded) {
                    Navigator.pop(context);
                  } else if (state is SyllabusUploaded) {
                    Navigator.pop(context);
                    DialogHelper.showMessage(context, 'تم رفع المنهج بنجاح',
                        Colors.green, TextStyleApp.font10White);
                    setState(() {
                      _selectedFile = null;
                      fileNameController.clear();
                    });
                  } else if (state is SyllabusOperationError) {
                    DialogHelper.errorMessage(context, state.message);
                  }
                } catch (e) {
                  // Ignore the error if the widget is no longer in the tree.
                }
              },
              builder: (context, state) {
                bool isUploading = state is SyllabusUploading;
                return AlertDialog(
                  title: const Text('إضافة منهج جديد'),
                  content: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: fileNameController,
                          decoration: const InputDecoration(
                            labelText: 'اسم المنهج',
                            border: OutlineInputBorder(),
                            hintText: 'أدخل اسم المنهج',
                          ),
                          enabled: !isUploading,
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton.icon(
                          onPressed: isUploading ? null : _pickFile,
                          icon: const Icon(Icons.attach_file),
                          label: const Text('اختر ملف PDF'),
                        ),
                        const SizedBox(height: 10),
                        if (_selectedFile != null) ...[
                          ListTile(
                            leading: const Icon(Icons.picture_as_pdf,
                                color: Colors.red),
                            title: Text(
                              _selectedFile!.name,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${(_selectedFile!.size / (1024 * 1024)).toStringAsFixed(2)} MB',
                              style: TextStyleApp.font8Grey,
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.close, size: 20),
                              onPressed: isUploading
                                  ? null
                                  : () {
                                      setState(() {
                                        _selectedFile = null;
                                        fileNameController.clear();
                                      });
                                    },
                            ),
                          ),
                        ],
                        if (isUploading) ...[
                          const SizedBox(height: 20),
                          const Column(
                            children: [
                              CircularProgressIndicator(),
                              SizedBox(height: 10),
                              Text('جاري رفع الملف...'),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: isUploading
                          ? null
                          : () {
                              Navigator.pop(context);
                              setState(() {
                                _selectedFile = null;
                                fileNameController.clear();
                              });
                            },
                      child: const Text('إلغاء'),
                    ),
                    ElevatedButton(
                      onPressed: isUploading
                          ? null
                          : () {
                              if (fileNameController.text.isEmpty ||
                                  _selectedFile == null) {
                                DialogHelper.errorMessage(
                                    context, 'الرجاء ملء جميع الحقول');
                                return;
                              }
                              _uploadSyllabus(context);
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: ColorsApp.primaryColor,
                      ),
                      child: const Text('رفع'),
                    ),
                  ],
                );
              },
            );
          },
        );
      },
    ).then((_) {
      // إعادة تعيين عند إغلاق الدايلوج
      setState(() {
        _selectedFile = null;
        fileNameController.clear();
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Card(
      elevation: 4,
      color: Colors.white,
      shadowColor: Colors.grey,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25),
      ),
      child: Column(
        children: [
          buildContainerBackGroundCardSyllabus(
            code: widget.courseWithSyllabiModel == null
                ? 'CSXX'
                : widget.courseWithSyllabiModel!.courseCode,
            name: widget.courseWithSyllabiModel == null
                ? 'CSXX'
                : widget.courseWithSyllabiModel!.courseName,
            context: context,
          ),
          Row(
            children: [
              Padding(
                padding: PaddingApp.hor15,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      widget.courseWithSyllabiModel == null
                          ? '0'
                          : widget.courseWithSyllabiModel!.syllabi.length
                              .toString(),
                      style: TextStyleApp.font10Grey.copyWith(
                        color: Colors.green,
                      ),
                    ),
                    Text(
                      'تم التنزيل',
                      style: TextStyleApp.font8Grey,
                    ),
                  ],
                ),
              ),
            ],
          ),
          Padding(
            padding: PaddingApp.getHorVer(15, 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox.shrink(),
                ButtonApp(
                  onTap: () {
                    if (widget.courseWithSyllabiModel == null) {
                      return;
                    } else if (widget.courseWithSyllabiModel!.syllabi.isEmpty) {
                      DialogHelper.errorMessage(
                          context, 'لم تقم بحفظ أي منهج بعد');
                    } else {
                      context.pushNamed(
                        RouterViews.syllabusCourse,
                        arguments: UserRequestCourseModel(
                          userModel: widget.userModel,
                          courseRequest: [],
                          courseWithSyllabiModel: widget.courseWithSyllabiModel,
                        ),
                      );
                    }
                  },
                  text: 'عرض المنهج',
                  colorButton: ColorsApp.primaryColor,
                  height: media.height * .04,
                  width: media.width * .5,
                ),
                GestureDetector(
                  onTap: () {
                    if (widget.courseWithSyllabiModel == null) {
                      return;
                    }
                    _openUploadDialog(context);
                  },
                  child: const CustomCircleIcon(
                    size: 30,
                    backGroundColor: Color(0xFFd7d9dd),
                    icon: Icons.upload,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildContainerBackGroundCardSyllabus({
    required String name,
    required String code,
    required BuildContext context,
  }) {
    var media = MediaQuery.of(context).size;
    return Container(
      padding: PaddingApp.getHorVer(15, 15),
      height: media.height * .09,
      decoration: const BoxDecoration(
        color: Color(0xFF3477f2),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const CustomCircleIcon(
                size: 25,
                backGroundColor: Color(0xFF5386f0),
                icon: Icons.code,
                sizeIcon: 12,
              ),
              getWidth(10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: TextStyleApp.font9White),
                  Text(code, style: TextStyleApp.font8White),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
