
import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_circle_icon.dart';

import '../../../../core/theme/box_decoration_app.dart';

class ConainerUpperBarSyllabus extends StatelessWidget {
  final int?countCourse;
  final int?countSyllabus;
  const ConainerUpperBarSyllabus({super.key , this.countCourse = 0 , this.countSyllabus = 0});

  @override
  Widget build(BuildContext context) {
    return Container(
    width: MediaQuery.of(context).size.width,
      decoration: BoxDecorationApp.gradientColorCustom3ColrosNoRaduis(
              const Color(0xFF9334ea),
              const Color(0xFF6c56ef),
              const Color(0xFF5F97F6))
          .copyWith(
        borderRadius: BorderRadius.circular(15),
       
      ),
      child:  Padding(
        padding: PaddingApp.getHorVer(10,15),
        child: Column(
          children: [
            Row(
              children: [
                const CustomCircleIcon(
                  icon: Icons.school,
                  backGroundColor: Color.fromARGB(75, 247, 247, 247) ,
                ),
            
                getWidth(10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مرحباً بك في موادك الدراسية' , style: TextStyleApp.font9White,),
                    Text('اختر المادة لعرض وتنزيل المناهج والمحاضرات الخاصة بها' , style: TextStyleApp.font7White,)
                  ],
                )
              ],
            ),
            const Divider(
              color: Color.fromARGB(64, 255, 255, 255),
            ),
            getHeight(5),
            Row(
              children: [
                const Icon(Icons.computer , size: 14, color: Colors.white,),
                getWidth(5),
                Text('$countCourse مواد' , style: TextStyleApp.font7White,),
                getWidth(10),
                
                const Icon(Icons.file_copy , size: 14, color: Colors.white,),
                getWidth(5),
                Text('$countSyllabus منهج' , style: TextStyleApp.font7White,)
              ],
            ),

            getHeight(10),
          ],
        ),
      ),
    );
  }
}