import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/model/syllabus_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';

import 'card_syllabus_course.dart';

class ListViewSyllabus extends StatelessWidget {
  final List<CourseWithSyllabiModel>? courseWithSyllabiModel;
  final UserModel userModel;
  final List<int> courseIds;
  const ListViewSyllabus({super.key ,  this.courseWithSyllabiModel , required this.userModel, required this.courseIds});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: courseWithSyllabiModel == null ? 4 : courseWithSyllabiModel !.length,
      itemBuilder: (context , index){
      return Padding(
        padding: PaddingApp.getHorVer(0,10),
        child: CardSyllabusCourse(
          courseIds : courseIds,
           userModel: userModel,
          courseWithSyllabiModel: courseWithSyllabiModel  == null ? null : courseWithSyllabiModel ![index],
        ),
      );
    });
  }
}