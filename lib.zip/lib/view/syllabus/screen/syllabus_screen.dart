import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_app_bar.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/syllabus/syllabus_cubit.dart';

import '../../../core/theme/text_style_app.dart';
import '../../../core/widget_app/check_owns_courses/column_no_course.dart';
import '../bloc/conainer_upper_bar_syllabus_bloc_builder.dart';
import '../bloc/list_view_syllabus_bloc_builder.dart';

class SyllabusScreen extends StatelessWidget {
  final UserModel userModel;
  final List<CurrentCourse> currentCourse;
  final List<CourseModel> courseRequest;
  const SyllabusScreen({super.key, required this.userModel, required this.currentCourse , required this.courseRequest});

  @override
  Widget build(BuildContext context) {
    context.read<SyllabusCubit>().fetchSyllabiForCourses(int.parse(userModel.userID),currentCourse.map((course) => int.parse(course.id)).toList(),);
    return SafeArea(child: Scaffold(
      appBar: CustomAppBar(
        center: true,
        toolbarHeight: 60,
        title: 'موادي الدراسية',
        textStyle: TextStyleApp.font12White,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back_ios_new_sharp,
              color: Colors.white,
            )),
      ),

      body: Column(
        
        children: [

          if(currentCourse.isEmpty) Expanded(child: ColumnNoCourse(userModel: userModel , courseRequest:courseRequest, currentCourse: currentCourse,)),
          if(currentCourse.isNotEmpty)   Expanded(
            child: Padding(
              padding: PaddingApp.getHorVer(15,15),
              child: Column(
                children: [
                  ConainerUpperBarSyllabusBlocBuilder(currentCourse: currentCourse,),
                  getHeight(20),
                  Expanded(child: ListViewSyllabusBlocBuilder(userModel: userModel, courseIds: currentCourse.map((course) => int.parse(course.id)).toList())),
                ],
              ),
            ),
          )
        
        ],
      ),
    ));
  }
}