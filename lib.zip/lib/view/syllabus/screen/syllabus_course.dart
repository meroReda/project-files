import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/model/syllabus_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';

import '../../../core/theme/text_style_app.dart';
import '../../../core/widget_app/custom_app_bar.dart';
import '../widget/syllabus_course/card_syllabus_course_delete_check.dart';

class SyllabusCourse extends StatelessWidget {
  final CourseWithSyllabiModel courseWithSyllabiModel;
  final UserModel userModel;
  const SyllabusCourse(
      {super.key,
      required this.courseWithSyllabiModel,
      required this.userModel});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          center: true,
          toolbarHeight: 60,
          title: courseWithSyllabiModel.courseName,
          textStyle: TextStyleApp.font12White,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back_ios_new_sharp,
                color: Colors.white,
              )),
        ),
        body: Padding(
          padding: PaddingApp.getHorVer(15, 15),
          child: Column(
            children: [
              getHeight(10),
              Row(
                children: [
                  const Icon(
                    Icons.file_copy_outlined,
                    color: Colors.blue,
                  ),
                  getWidth(15),
                  Text(
                      'المناهج والمحاضرات  ${courseWithSyllabiModel.syllabi.length}'),
                ],
              ),
              getHeight(10),
              Expanded(child: ListView.builder(
                itemCount: courseWithSyllabiModel.syllabi.length,
                itemBuilder: (context , index){
                   return CardSyllabusCourseDeleteCheck(syllabusModel: courseWithSyllabiModel.syllabi[index]);
              }))
            ],
          ),
        ),
      ),
    );
  }
}
