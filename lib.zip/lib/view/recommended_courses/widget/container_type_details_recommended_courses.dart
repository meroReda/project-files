import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';

import '../../../core/theme/box_decoration_app.dart';

class ContainerTypeDetailsRecommendedCourses extends StatelessWidget {

  const ContainerTypeDetailsRecommendedCourses(
      {super.key,});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Container(
      height: media.height * .1,
      width: media.width,
      decoration: BoxDecorationApp.customColorRaduis24ListGradient(null, [
        const Color(0xFFa058f7),
        const Color(0xFF477df6),
      ]),
      child: Row(
        children: [
          getWidth(20),
          const CircleAvatar(
            radius: 20,
            backgroundColor:  Color(0xFFffffff),
            child:  Icon(Icons.transform_outlined),
          ),
          getWidth(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                getHeight(10),
                Text(
                  'مواد الفصل الحالي',
                  style: TextStyleApp.font11White
                      .copyWith(fontWeight: FontWeight.w500),
                ),
                Expanded(
                    child: Text(
                  'هذه المواد متاحة التي تم تسجيلها في الفصل الدراسي الحالي',
                  style: TextStyleApp.font7White,
                ))
              ],
            ),
          )
        ],
      ),
    );
  }
}
