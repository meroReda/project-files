import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/theme/colors_app.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/widget_app/button_app.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import '../../../core/helpers/size_box_responsive.dart';
import '../../../core/theme/text_style_app.dart';

class AppBarRecommendedCourses extends StatelessWidget {
  final UserModel userModel;
  const AppBarRecommendedCourses({super.key, required this.userModel});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 12,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(0),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.arrow_back_ios_new)),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      getHeight(10),
                      Text(
                        'مواد الفصل الحالي',
                        style: TextStyleApp.font10Black,
                      ),
                      Text(
                        'يمكنك تعديل حسب إحتياجاتك',
                        style: TextStyleApp.font8Grey,
                      ),
                    ],
                  ),
                ],
              ),
           
              Padding(
                padding: PaddingApp.getOnlyPadding(0, 7,0,0),
                child: ButtonApp(
                  colorButton: ColorsApp.primaryColor,
                  borderRadius: BorderRadius.circular(8),
                  text: 'إضافة مادة',
                  width: MediaQuery.of(context).size.width *.24,
                  onTap: () {
                    context.pushNamed(RouterViews.customizeCoursesOfSemester , arguments: userModel);
                  },
                ),
              )
            ],
          ),
          getHeight(20),
          Padding(
            padding: PaddingApp.hor20,
            child: Container(
              decoration: BoxDecoration(
                color: const Color.fromARGB(198, 9, 90, 241),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Row(
                children: [
                  getWidth(5),
                  const Icon(Icons.transform_outlined , color: Colors.white,),
                  getWidth(10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getHeight(10),
                        Text(
                          'مواد الفصل الحالي',
                          style: TextStyleApp.font11White
                              .copyWith(fontWeight: FontWeight.w500),
                        ),
                        Text(
                          'هذه المواد متاحة التي تم تسجيلها في الفصل الدراسي الحالي',
                          style: TextStyleApp.font7White,
                        ),
                        getHeight(20),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          getHeight(10),
        ],
      ),
    );
  }
}
