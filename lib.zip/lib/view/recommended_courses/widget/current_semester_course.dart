import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/button_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_circle_icon.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/view_model/home/home_cubit.dart';
import '../../../model/user_model.dart';

class CurrentSemesterCourse extends StatelessWidget {
  final CurrentCourse course;
  final UserModel userModel;
  const CurrentSemesterCourse(
      {super.key, required this.course, required this.userModel});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Padding(
      padding: PaddingApp.ver10,
      child: Card(
        color: Colors.white,
        elevation: 8,
        child: Column(
          children: [
            buildUpperBarCardCurrentCourse(
                code: course.code,
                name: course.name,
                unit: int.parse(course.unit),
                context: context),
      
                getHeight(20),
      
                ButtonApp(
                  width: media.width *.45,
                  childWidget: Text('إسقاط المادة' , style: TextStyleApp.font10White.copyWith(color: Colors.red),),
                  colorButton: const Color(0xFFfef2f2),

                  onTap: (){
                    context.read<HomeCubit>().deleteCourseForUserInCubit(userModel,course, context,int.parse(course.unit));
                  },
                ),
                getHeight(10),
          ],
        ),
      ),
    );
  }

  Widget buildUpperBarCardCurrentCourse(
      {required String name,
      required String code,
      required int unit,
      required BuildContext context}) {
    var media = MediaQuery.of(context).size;
    return Container(
      height: media.height * .12,
      width: media.width,
      decoration: const BoxDecoration(
        color: Color(0xFF2f71f0),
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(15), topLeft: Radius.circular(15)),
      ),
      child: Padding(
        padding: PaddingApp.getHorVer(10,10),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const CustomCircleIcon(
                      backGroundColor:  Color(0xFF5385f0),
                      icon: Icons.code,
                    ),
                    getWidth(10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name, style: TextStyleApp.font10White),
                        Text(
                          code,
                          style: TextStyleApp.font8White,
                        ),
                      ],
                    )
                  ],
                ),
                Container(
                  padding: PaddingApp.getHorVer(10,10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF5385f0),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Center(
                    child: Text('$unit وحدة' , style: TextStyleApp.font10White,),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
