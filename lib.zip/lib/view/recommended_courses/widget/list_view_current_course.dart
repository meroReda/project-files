import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'current_semester_course.dart';

class ListViewCurrentCourse extends StatelessWidget {
  final UserModel userModel;
  final List<CurrentCourse> currentCourse;
  const ListViewCurrentCourse(
      {super.key, required this.userModel, required this.currentCourse});

  @override
  Widget build(BuildContext context) {
    return   Padding(
      padding: PaddingApp.hor15,
      child: ListView.builder(
            itemCount: currentCourse.length,
            itemBuilder: (context, index) {
            final course  = currentCourse[index];
            return CurrentSemesterCourse(course: course, userModel: userModel);
          }),
    );
  }
}
