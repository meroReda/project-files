import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/widget_app/check_owns_courses/column_no_course.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view/recommended_courses/widget/list_view_current_course.dart';
import 'package:smart_assistant_app/view_model/home/home_cubit.dart';
import 'package:smart_assistant_app/view_model/home/home_state.dart';
import '../widget/app_bar_recommended_courses.dart';

class MenuForRecommendedCoursesBlocBuilder extends StatelessWidget {
  final UserModel userModel;
  const MenuForRecommendedCoursesBlocBuilder(
      {super.key, required this.userModel});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomeCubit, HomeState>(
        builder: (context, state) {
          if (state.coursesUser!.currentCourse == null || state.coursesUser!.currentCourse.isEmpty) {
            return Expanded( child: ColumnNoCourse(userModel: userModel,courseRequest: state.coursesUser!.courseRequest,currentCourse: state.coursesUser!.currentCourse));
          }
           else if (state.status == HomeStatus.success) {
        
            return Expanded(
              child: Column(
                children: [
                   AppBarRecommendedCourses(userModel: state.userModel!,),
                   Expanded(child: ListViewCurrentCourse(userModel: state.userModel!, currentCourse: state.coursesUser!.currentCourse)),
                ],
              ),
            );
          } else if (state.status == HomeStatus.loading) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                getHeight(150),
                const Center(child: CircularProgressIndicator()),
              ],
            );
          }
          return const SizedBox.shrink();
        },
        listener: (context, state) {});
  }
}
