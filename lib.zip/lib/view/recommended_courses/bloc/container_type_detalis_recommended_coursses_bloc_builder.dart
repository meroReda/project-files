import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skeletonizer/skeletonizer.dart';
import '../../../view_model/home/home_cubit.dart';
import '../../../view_model/home/home_state.dart';
import '../widget/container_type_details_recommended_courses.dart';

class ContainerTypeDetalisRecommendedCourssesBlocBuilder
    extends StatelessWidget {
  const ContainerTypeDetalisRecommendedCourssesBlocBuilder({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeCubit, HomeState>(builder: (context, state) {
      if(state.coursesUser!.currentCourse == null || state.coursesUser!.currentCourse.isEmpty) { 
        return const SizedBox.shrink(); }
      else if (state.status == HomeStatus.success  && state.coursesUser!.currentCourse != null || state.coursesUser!.currentCourse.isNotEmpty) {
        return const ContainerTypeDetailsRecommendedCourses( );
      }
      if (state.coursesUser!.currentCourse != null || state.coursesUser!.currentCourse.isNotEmpty) {
        return const Skeletonizer(
          child: ContainerTypeDetailsRecommendedCourses(),
        );
      }
      return const SizedBox.shrink();
    });
  }
}
