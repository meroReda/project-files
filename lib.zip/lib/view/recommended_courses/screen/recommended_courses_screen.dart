import 'package:flutter/material.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import '../bloc/menu_for_recommended_courses_bloc_builder.dart';
class RecommendedCoursesScreen extends StatelessWidget {
  final UserModel userModel;
  final List<CurrentCourse>? currentCourse;
  final List<CourseModel> courseRequest;
  const RecommendedCoursesScreen({super.key, required this.userModel, this.currentCourse, required this.courseRequest});

  @override
  Widget build(BuildContext context) {
    return  SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFf8f5ff),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MenuForRecommendedCoursesBlocBuilder(userModel: userModel,),
          ],
        ),
        
      ),
    );
  }
}
