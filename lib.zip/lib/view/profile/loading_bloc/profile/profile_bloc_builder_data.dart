import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/profile/profile_cubit.dart';
import 'package:smart_assistant_app/view_model/profile/profile_state.dart';

import '../../../../core/helpers/size_box_responsive.dart';
import '../../widget/profile/card_info_account.dart';
import '../../widget/profile/container_upper_bar_profile.dart';

class ProfileBlocBuilderData extends StatelessWidget {
  const ProfileBlocBuilderData({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfileCubit, ProfileState>(builder: (context, state) {
      UserModel? user = state.userModel;
      return Skeletonizer(
        enabled: state.status == ProfileStatus.loading,
        child: Column(
          children: [
            ContainerUpperBarProfile(
              userModel: user,
            ),
            getHeight(20),
            CardInfoAccount(
              userModel: user,
            ),
          ],
        ),
      );
    });
  }
}
