import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/server/local_storage.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/button_app.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view/profile/widget/profile/quick_actions_account.dart';
import 'package:smart_assistant_app/view_model/profile/profile_cubit.dart';
import '../../../core/helpers/size_box_responsive.dart';
import '../loading_bloc/profile/profile_bloc_builder_data.dart';

class ProfileScreen extends StatelessWidget {
  final UserModel userModel;
  const ProfileScreen({super.key, required this.userModel});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    context.read<ProfileCubit>().getUser(userModel);
    return SafeArea(
        child: Scaffold(
      backgroundColor: const Color(0xFFf9fafb),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: PaddingApp.hor15,
              child: Column(
                children: [
                  getHeight(20),
                  const ProfileBlocBuilderData(),
                  getHeight(20),
                  const QuickActionsAccount(),
                  getHeight(20),
                  ButtonApp(
                    width: media.width,
                    height: media.height * .06,
                    text: 'تسجيل الخروج',
                    textStyle:
                        TextStyleApp.font10Grey.copyWith(color: Colors.red),
                    onTap: () {
                      LocalStorage.clearUser();
                      context.pushAndRemoveUntil(RouterViews.login);
                    },
                    boxDecoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                            width: 0.5, color: const Color(0xFFfdd9d9))),
                  ),
                  getHeight(20),
                ],
              ),
            ),
          )
        ],
      ),
    ));
  }
}
