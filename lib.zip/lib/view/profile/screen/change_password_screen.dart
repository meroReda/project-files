import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/valid_function_app.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/view/profile/widget/change_password/container_upper_bar_change_password.dart';
import 'package:smart_assistant_app/view_model/profile/profile_cubit.dart';

import '../../../core/helpers/size_box_responsive.dart';
import '../loading_bloc/change_password/button_change_password_bloc_builder.dart';
import '../widget/change_password/card_filed_change_password.dart';
import '../widget/change_password/container_password_requirements.dart';

class ChangePasswordScreen extends StatelessWidget {
  const ChangePasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ProfileCubit>();
    return SafeArea(
        child: Scaffold(
      backgroundColor: const Color(0xFFf9fafb),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: PaddingApp.hor15,
              child: Form(
                key: cubit.formKey,
                child: Column(
                  children: [
                    getHeight(20),
                    const ContainerUpperBarChangePassword(),
                    getHeight(20),
                    CardFiledChangePassword(
                      label: 'كلمة المرور الحالية',
                      hint: 'ادخل كلمة المرور الحالية',
                      controller: cubit.currentPasswordController,
                      validator: (value) {
                        String? error =
                            ValidFunctionApp.validatePassword(value!);
                        if (error.isEmpty) {
                          error = cubit.password == value
                              ? ''
                              : 'كلمة مرور ليست نفسها';
                        }
                        return error.isEmpty ? null : error;
                      },
                    ),
                    getHeight(10),
                    CardFiledChangePassword(
                      controller: cubit.newPasswordController,
                      label: 'كلمة المرور الجديدة',
                      hint: 'ادخل كلمة المرور الجديدة',
                      validator: (value) {
                        String? error =
                            ValidFunctionApp.validatePassword(value!);
                        return error.isEmpty ? null : error;
                      },
                      onChanged: (value) {
                        context.read<ProfileCubit>().validatePassword(value);
                      },
                    ),
                    getHeight(10),
                    CardFiledChangePassword(
                      label: 'تأكيد كلمة المرور الجديدة',
                      hint: 'أعد كلمة المرور الجديدة',
                      controller: cubit.confirmPasswordController,
                      validator: (value) {
                        String? error;
                        if (cubit.newPasswordController.text != value) {
                          error = 'كلمة المرور ليست متشابهة';
                        } else {
                          error = ValidFunctionApp.validatePassword(value!);
                        }
                        return error.isEmpty ? null : error;
                      },
                    ),
                    getHeight(20),
                    const ContainerPasswordRequirements(),
                    getHeight(10),
                    const ButtonChangePasswordBlocBuilder(),
                    getHeight(50),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    ));
  }
}
