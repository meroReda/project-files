import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/home/home_cubit.dart';
import '../../../../view_model/home/home_state.dart';

class ContainerUpperBarProfile extends StatelessWidget {
  final UserModel? userModel;
  const ContainerUpperBarProfile({super.key, this.userModel});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return Container(
      height: media.height * 0.25,
      decoration: BoxDecoration(
        color: const Color(0xFF367bf3),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: PaddingApp.getHorVer(15, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            getHeight(10),
            Row(
              children: [
                _buildProfileIcon(),
                getWidth(10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getHeight(5),
                    Text(userModel == null ? 'جاري التحميل ' : userModel!.fullName,
                        style: TextStyleApp.font12White),
                    Text('علوم حاسب',
                        style: TextStyleApp.font9White
                            .copyWith(color: const Color(0xFF8cb1f7))),
                  ],
                ),
              ],
            ),
            getHeight(20),
            _buildStatsContainer(context, media, userModel),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileIcon() => Container(
        height: 60,
        width: 60,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF7ea7f6),
          border: Border.fromBorderSide(
              BorderSide(width: 5, color: Color.fromARGB(31, 255, 255, 255))),
        ),
        child: const Icon(Icons.person, color: Colors.white, size: 32),
      );

  Widget _buildStatsContainer(BuildContext context, Size media,UserModel ? userModel) =>
      Container(
        padding: PaddingApp.hor15,
        height: media.height * 0.1,
        width: media.width * 0.85,
        decoration: BoxDecoration(
          color: const Color.fromARGB(31, 255, 255, 255),
          borderRadius: BorderRadius.circular(15),
        ),
        child: BlocBuilder<HomeCubit, HomeState>(
          builder: (context, state) => state.status == HomeStatus.success
              ? _buildStatsRow(state, userModel)
              : const SizedBox.shrink(),
        ),
      );

  Widget _buildStatsRow(HomeState state, UserModel? userModel) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildStatItem(
            value: state.coursesUser!.totalNumberOfCompletedUnits.toString(),
            label: 'ساعات المنجزة',
          ),
          _buildVerticalDivider(),
          _buildStatItem(
            value: state.coursesUser!.totalCompletedCourses.toString(),
            label: 'المواد المنجزة',
          ),
          _buildVerticalDivider(),
          _buildStatItem(
            value: userModel == null ?  '-' :  userModel.yearOfJoining!,
            label: 'سنة الالتحاق',
          ),
        ],
      );

  Widget _buildStatItem({required String value, required String label}) =>
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, style: TextStyleApp.font12White),
          Text(label, style: TextStyleApp.font8White),
        ],
      );

  Widget _buildVerticalDivider() => Container(
        height: 50,
        width: 0.5,
        color: Colors.white,
      );
}
