import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';

class RowAndDivder extends StatelessWidget {
  final String label;
  const RowAndDivder({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
          Text(label , style: TextStyleApp.font10Black.copyWith(fontWeight: FontWeight.bold),),
          const Divider(color: Color.fromARGB(69, 158, 158, 158),)
      ],
    );
  }
}
