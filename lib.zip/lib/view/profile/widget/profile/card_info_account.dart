import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/colors_app.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view/profile/widget/profile/custom_circle_icon.dart';
import 'package:smart_assistant_app/view/profile/widget/profile/row_and_divder.dart';

class CardInfoAccount extends StatelessWidget {
  final UserModel? userModel;
  const CardInfoAccount({super.key , this.userModel});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return SizedBox(
      height: media.height * .27,
      width: media.width,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0), // هنا تحدد قيمة التدوير
        ),
        shadowColor: ColorsApp.primaryColor,
        color: Colors.white,
        child: Padding(
          padding: PaddingApp.getHorVer(15, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              getHeight(5),
              const RowAndDivder(label: 'معلومات الحساب'),
              getHeight(5),
              BuildRowInfoAccount(
                backgroundColor: const Color(0xFFeff6ff),
                label: 'الاسم الكامل',
                value: userModel == null ? '-' :  userModel!.fullName,
                colorIcon: Colors.blue,
                iconData: Icons.person,
              ),
              BuildRowInfoAccount(
                backgroundColor: const Color(0xFFedfaf1),
                label: 'البريد الإلكتروني',
                value: userModel == null ? '-' : userModel!.email,
                colorIcon: const Color(0xFF6bc9ac),
                iconData: Icons.email,
              ),
              const BuildRowInfoAccount(
                backgroundColor: Color(0xFFddd9ee),
                label: 'التخصص',
                value: 'علوم الحاسب',
                colorIcon: Color(0xFFae88e7),
                iconData: Icons.computer_outlined,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BuildRowInfoAccount extends StatelessWidget {
  const BuildRowInfoAccount({
    super.key,
    required this.value,
    required this.label,
    required this.iconData,
    required this.colorIcon,
    required this.backgroundColor,
  });

  final String value;
  final String label;
  final IconData iconData;
  final Color colorIcon;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: PaddingApp.getHorVer(0, 8),
      child: Row(
        children: [
          CustomCircleIcon(
              height: 40,
              width: 40,
              icon: iconData,
              iconColor: colorIcon,
              backgroundColor: const Color(0xFFeff6ff)),
          getWidth(10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyleApp.font6Grey,
              ),
              Text(
                value,
                style: TextStyleApp.font8Black
                    .copyWith(fontWeight: FontWeight.w500),
              ),
            ],
          )
        ],
      ),
    );
  }
}
