import 'package:flutter/material.dart';

class CustomCircleIcon extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final double? height;
  final double ? sizeIcon;
  final double? width;
  final Color  backgroundColor;
  const CustomCircleIcon({super.key, required this.icon, required this.iconColor, this.height, this.width, required this.backgroundColor, this.sizeIcon});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? 50,
      width: width ?? 50,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: backgroundColor,
      ),
      child: Icon(icon , color: iconColor, size: sizeIcon ?? 18,),
    );
  }
}