import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/view/profile/widget/profile/custom_circle_icon.dart';
import 'package:smart_assistant_app/view/profile/widget/profile/row_and_divder.dart';
import '../../../../core/helpers/size_box_responsive.dart';
import '../../../../core/theme/colors_app.dart';
import '../../../../core/theme/padding_app.dart';
import '../../../../view_model/profile/profile_cubit.dart';

class QuickActionsAccount extends StatelessWidget {
  const QuickActionsAccount({super.key});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return SizedBox(
      height: media.height * .35,
      width: media.width,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0), // هنا تحدد قيمة التدوير
        ),
        shadowColor: ColorsApp.primaryColor,
        color: Colors.white,
        child: Padding(
          padding: PaddingApp.getHorVer(15, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              getHeight(5),
              const RowAndDivder(label: 'الإجراءات السريعة'),
              getHeight(5),
              const RowQuickActionsAccount(iconColor: Colors.blue, label: 'تحديث مواد المنجزة', iconData: Icons.check, ),
                RowQuickActionsAccount(iconColor: Colors.green, label: 'تغيير كلمة المرور', iconData: Icons.lock, onTap: (){
                  context.pushNamed(RouterViews.chagePassword);
                   context.read<ProfileCubit>().resetPasswordFields();
                },),
              const RowQuickActionsAccount(iconColor: Color(0xFF14bec4), label: 'إعداد سؤال الأمان', iconData: Icons.safety_check_sharp,),
              const RowQuickActionsAccount(iconColor: Color(0xFFa858f8), label: 'تحديث الصورة الشخصية', iconData: Icons.image,),
            ],
          ),
        ),
      ),
    );
  }
}

class RowQuickActionsAccount extends StatelessWidget {
  const RowQuickActionsAccount({
    super.key, required this.iconData, required this.iconColor, required this.label, this.onTap,
  });
  final IconData iconData;
  final Color  iconColor;
  final String label;
  final VoidCallback ? onTap;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: PaddingApp.getHorVer(0,10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
           Row(
            children: [
              CustomCircleIcon(height: 35, width: 35, icon: iconData, iconColor: iconColor, backgroundColor: const Color(0xFFeff6ff),),
              getWidth(10),
              Text(label , style: TextStyleApp.font9Black,),
            ],
           ),
           const Icon(Icons.arrow_forward_ios_rounded , size: 18, color: Colors.grey,),
          ],
        ),
      ),
    );
  }
}