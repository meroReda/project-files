import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/view_model/profile/profile_cubit.dart';
import 'package:smart_assistant_app/view_model/profile/profile_state.dart';

class ContainerPasswordRequirements extends StatelessWidget {
  const ContainerPasswordRequirements({super.key});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    final cubit = context.read<ProfileCubit>();
    return Container(
      height: media.height * .2,
      width: media.width,
      decoration: BoxDecoration(
        color: const Color(0xFFf6f5ff),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: PaddingApp.getHorVer(15, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.info,
                  color: Colors.purple,
                  size: 16,
                ),
                getWidth(10),
                Text(
                  'متطلبات كلمة المرور',
                  style: TextStyleApp.font10Black
                      .copyWith(fontWeight: FontWeight.w400),
                ),
              ],
            ),
            getHeight(10),
            BlocBuilder<ProfileCubit, ProfileState>(builder: (context, state) {
              return Column(
                  children: List.generate(cubit.conditions.length, (index) {
                final label = cubit.conditions[index];
                return Padding(
                  padding: PaddingApp.getHorVer(0, 5),
                  child: Row(
                    children: [
                      Container(
                        height:  15,
                        width: 15,
                        decoration: BoxDecoration(
                            color: state.list[index] ? Colors.green :  Colors.white,
                            shape: BoxShape.circle,
                            border: state.list[index] ? null :  Border.all(width: 1, color: Colors.grey)),
                        child: state.list[index] ? const Icon(Icons.check , color: Colors.white, size: 12,) : null,
                      ),
                      getWidth(8),
                      Text(
                        label,
                        style: TextStyleApp.font8Grey.copyWith(color:  state.list[index] ? Colors.green : null),
                      )
                    ],
                  ),
                );
              }));
            }),
          ],
        ),
      ),
    );
  }
}
