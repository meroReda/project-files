import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/text_filed_app.dart';

import '../../../../core/theme/colors_app.dart';

class CardFiledChangePassword extends StatelessWidget {
  final TextEditingController? controller;
  final String label;
  final String hint;
  final String? Function(String?)? validator;
    final Function(String)? onChanged; // إضافة onChanged

  const CardFiledChangePassword(
      {super.key,
      this.controller,
      required this.label,
      required this.hint,
      this.validator, this.onChanged});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return SizedBox(
      height: media.height * .15,
      width: media.width,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        shadowColor: ColorsApp.primaryColor,
        color: Colors.white,
        child: Padding(
          padding: PaddingApp.getHorVer(10, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyleApp.font10Black
                    .copyWith(fontWeight: FontWeight.w500),
              ),
              getHeight(10),
              TextFiledApp(
                errorBorder:OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: const BorderSide(color: Colors.red, width: 0.001)
                ), 
                onChanged: onChanged,
                validator: validator,
                width: media.width*.92,
                controller: controller,
                label: hint,
                isPassword: true,
                textStyle: TextStyleApp.font9Black,
                textStyleLabel: TextStyleApp.font9Grey,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: const BorderSide(color: Colors.grey , width: 0.001)
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: const BorderSide(color: Colors.blue , width: 0.8)
                ),
                prefixIcon: const Icon(
                  Icons.lock,
                  size: 15,
                  color: Colors.grey,
                ),
                fillColor: const Color(0xFFf9fafb),
              )
            ],
          ),
        ),
      ),
    );
  }
}
