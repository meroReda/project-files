import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';

class ContainerUpperBarChangePassword extends StatelessWidget {
  const ContainerUpperBarChangePassword({super.key});

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;
    return Container(
      height: media.height * 0.14,
      decoration: BoxDecoration(
        color: const Color(0xFF2766ec),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: PaddingApp.getHorVer(15,10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            getHeight(10),
            Row(
              children: [
                _buildProfileIcon(),
                getWidth(10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      getHeight(5),
                      Text('حماية حسابك', style: TextStyleApp.font12White),
                      Text('اختر كلمة مرور قوية لحماية حسابك. يجب أن تحتوي على أحرف كبيرة وصغيرة وأرقام.', style: TextStyleApp.font9White.copyWith(color: const Color(0xFF8cb1f7))),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileIcon() => Container(
    height: 50,
    width: 50,
    decoration: const BoxDecoration(
      shape: BoxShape.circle,
      color: Color(0xFF5385f0),
    ),
    child: const Icon(Icons.safety_check, color: Colors.white, size: 32),
  );

}