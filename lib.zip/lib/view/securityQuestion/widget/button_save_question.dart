import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/button_app.dart';
import 'package:smart_assistant_app/core/widget_app/loading_button.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_cubit.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_state.dart';

class ButtonSaveQuestion extends StatelessWidget {
  final UserModel userModel;
  const ButtonSaveQuestion({super.key , required this.userModel});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return BlocConsumer<SecurityQuestionCubit , SecurityQuestionState>(builder: (context , state){
        final cubit = context.read<SecurityQuestionCubit>();
        bool isEmptyAnswer = cubit.answerController.text.isEmpty;
          return ButtonApp(
            onTap: (){
              if(isEmptyAnswer == false) {
                cubit.callRep(userModel);
              }
            },
            width: media.width,
            boxDecoration: BoxDecoration(
              color: isEmptyAnswer ?const Color(0xFFe5e7eb) : Colors.green,
              borderRadius: BorderRadius.circular(15),
            ),
            childWidget: state is SecurityQuestionLoading ?  const LoadingButton() :  Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.save , size: 18, color: isEmptyAnswer ? Colors.grey : Colors.white,),
                getWidth(10),
                Text('حفظ سؤال الامان' , style: isEmptyAnswer ? TextStyleApp.font12Grey : TextStyleApp.font12White)
              ],
            ),
          );
        

    }, listener: (context,state){
      if(state is SecurityQuestionSucces){
        context.pushAndRemoveUntil(RouterViews.completedCourses , arguments: userModel);
      }
      
    });
  }
}