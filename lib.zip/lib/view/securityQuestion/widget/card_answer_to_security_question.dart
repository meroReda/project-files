import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/theme/colors_app.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/widget_app/text_filed_app.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_cubit.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_state.dart';

import '../../../core/helpers/size_box_responsive.dart';
import '../../../core/theme/text_style_app.dart';

class CardAnswerToSecurityQuestion extends StatelessWidget {
  const CardAnswerToSecurityQuestion({super.key});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return BlocBuilder<SecurityQuestionCubit, SecurityQuestionState>(
        builder: (context, state) {
      final cubit = context.read<SecurityQuestionCubit>();
      if (cubit.indexselectedQuestion == -1) {
        return const SizedBox.shrink();
      }
      return Padding(
        padding: PaddingApp.hor5,
        child: Column(
          children: [
           
            Container(
              width: media.width,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: PaddingApp.hor15,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getHeight(10),
                    Row(
                      children: [
                        Container(
                          height: 30,
                          width: 30,
                          decoration: const BoxDecoration(
                              color: Color(0xFFdcfce7), shape: BoxShape.circle),
                          child: const Icon(
                            Icons.edit,
                            color: Colors.green,
                          ),
                        ),
                        getWidth(5),
                        Text(
                          'أدخل الإجابة',
                          style: TextStyleApp.font9Black
                              .copyWith(fontWeight: FontWeight.w600),
                        )
                      ],
                    ),
                    getHeight(10),
                    Container(
                      height: media.height * .06,
                      width: media.width,
                      decoration: BoxDecoration(
                          color: ColorsApp.primaryColor,
                          borderRadius: BorderRadius.circular(15)),
                      child: Center(
                        child: Text(
                          cubit.securityQuestionsAr[cubit.indexselectedQuestion],
                          style: TextStyleApp.font10White,
                        ),
                      ),
                    ),
                    getHeight(10),
                  
                    TextFiledApp(
                      onChanged: (value) {
                        cubit.updateAnswer(value);
                        return '';
                      },
                      label: 'اكتب إجابتك هنا',
                      controller: cubit.answerController,
                      textStyle: TextStyleApp.font8Black,
                      outlineInputBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: const BorderSide(
                            width: 0.5,
                            color: Colors.grey,
                          )),
                    ),
                    Padding(
                      padding: PaddingApp.getHorVer(0, 5),
                      child: Text(
                        'تأكد من كتابة إجابة يسهل عليك تذكرها. .',
                        style: TextStyleApp.font8Grey,
                      ),
                    ),
                     getHeight(20),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}
