import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_cubit.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_state.dart';

class CardDisplayQuestion extends StatelessWidget {
  const CardDisplayQuestion({super.key});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Container(

      width: media.width,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: PaddingApp.hor15,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            getHeight(10),
            Row(
              children: [
                Container(
                  height: 30,width: 30,
                  decoration: const BoxDecoration(
                    color: Color(0xFFdbeafe),
                    shape: BoxShape.circle
                  ),
                child: const Icon(Icons.info , color: Colors.blue,),
                ),
                getWidth(5),
                Text('اختر سؤال الأمان' , style: TextStyleApp.font9Black.copyWith(fontWeight: FontWeight.w600),)
              ],
            ),
           getHeight(20),
            BlocBuilder<SecurityQuestionCubit, SecurityQuestionState>(
              builder: (context, state) {
               return  Column(
                children: List.generate(context.read<SecurityQuestionCubit>().securityQuestionsAr.length,(index){
                  final qusetion = context.read<SecurityQuestionCubit>().securityQuestionsAr[index];
                  return Padding(
                    padding: PaddingApp.getOnlyPadding(0,0,0, 8),
                    child: GestureDetector(
                      onTap: () => context.read<SecurityQuestionCubit>().selectedQuestionIndex(index),
                      child: RowShowQuestion(text: qusetion, media: media,selected: index == context.read<SecurityQuestionCubit>().indexselectedQuestion,)),
                  );
                }
                )
              );
              },
            )
          ],
        ),
      ),
    );
  }
}

class RowShowQuestion extends StatelessWidget {
  const RowShowQuestion({
    super.key,
    required this.media,
    required this.text,
    this.selected = false,
  });

  final Size media;
  final String text;
  final bool? selected;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: media.height *.07,
      width: media.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(width: selected! ? 1 :  0.4 , color: selected! ? const Color(0xFF3b82f6) : Colors.grey),
        color: selected! ? const Color(0xFFeff6ff) : Colors.white
      ),
      child: Padding(
        padding: PaddingApp.getHorVer(15, 0),
        child: Row(
          
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
                 Text(text , style: TextStyleApp.font9Black.copyWith(fontWeight: FontWeight.bold , color: selected! ? Colors.blue : null,),),
                 Container(
                  height: 30,width: 30,
                  decoration: BoxDecoration(
                    color: selected! ?  const Color(0xFF3b82f6) : Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(width: 0.5 , color: Colors.grey)
                  ),
                  child: selected! ? const Icon(Icons.check , color: Colors.white,size: 18,) : null,
                 )
          ],
        ),
      ),
    );
  }
}
