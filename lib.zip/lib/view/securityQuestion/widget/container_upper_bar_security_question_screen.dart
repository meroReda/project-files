import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import '../../../core/theme/box_decoration_app.dart';

class ContainerUpperBarSecurityQuestionScreen extends StatelessWidget {
  const ContainerUpperBarSecurityQuestionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Container(
      height: media.height * .15,
      width: media.width,
      decoration: BoxDecorationApp.gradientColorCustom3ColrosRaduis15(
          const Color(0xFF8734E1),
          const Color(0xFF4A6Cf7),
          const Color(0xFF5F97F6)),
    child: Padding(
      padding: PaddingApp.getHorVer(20, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
           Text('لماذا سؤال الأمان؟' , style: TextStyleApp.font10White,),
           Expanded(child:
            Text('سؤال الأمان يساعدك على استعادة حسابك في حالة نسيان كلمة المرور. اختر سؤالاً يسهل عليك تذكر إجابته ولكن يصعب على الآخرين تخمينها.'
            , style: TextStyleApp.font9White,
            ))
        ],
      ),
    ),
    );
  }
}
