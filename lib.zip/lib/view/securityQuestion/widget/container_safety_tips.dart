import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_cubit.dart';

class ContainerSafetyTips extends StatelessWidget {
  const ContainerSafetyTips({super.key});

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Padding(
      padding: PaddingApp.getHorVer(0,10),
      child: Container(
          height: media.height*.18,
          width: media.width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            border: Border.all(width: 0.8 , color: const Color(0xFFfef08a)),
            color: const Color(0xFFfefbe8),
            
          ),
          child: Padding(
            padding: PaddingApp.getHorVer(20, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                   Row(
                    children: [
                      const Icon(Icons.quiz_sharp ,color: Colors.orange,size: 20,),
                      getWidth(5),
                      Text('نصائح الأمان', style: TextStyleApp.font9Black)
                    ],
                   ),
                   getHeight(20),
                   Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(context.read<SecurityQuestionCubit>().stepList.length, (index){
                      final text = context.read<SecurityQuestionCubit>().stepList[index];
                      return Padding(
                        padding: PaddingApp.getOnlyPadding(0,0,0,5),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CircleAvatar(
                              radius: 8,
                              backgroundColor: Colors.green,
                              child: Icon(Icons.check ,color: Colors.white,size: 12,),
                            ),
                            getWidth(5),
                            Text(text , style: TextStyleApp.font8Black,)
                          ],
                        ),
                      );
                    })
                   )
              ],
            ),
          ),
      ),
    );
  }
}