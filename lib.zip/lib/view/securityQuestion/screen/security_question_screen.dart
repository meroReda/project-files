import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/padding_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/core/widget_app/custom_app_bar.dart';
import 'package:smart_assistant_app/view/securityQuestion/widget/card_display_question.dart';
import 'package:smart_assistant_app/view/securityQuestion/widget/container_upper_bar_security_question_screen.dart';
import '../../../model/user_model.dart';
import '../widget/button_save_question.dart';
import '../widget/card_answer_to_security_question.dart';
import '../widget/container_safety_tips.dart';

class SecurityQuestionScreen extends StatelessWidget {
  final UserModel userModel;
  const SecurityQuestionScreen({super.key, required this.userModel});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          backgroundColor: const Color(0xFFfefeff),
          toolbarHeight: 60,
          widgettitle: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'سؤال الامان',
                    style: TextStyleApp.font10Black.copyWith(color: const Color(0xFF8756ec)),
                  ),
                  Text(
                    'لحماية حسابك واستعادته',
                    style: TextStyleApp.font10Grey,
                  )
                ],
              ),
            ],
          ),
        ),
        backgroundColor: const Color(0xFFf3f6ff),
        body: SingleChildScrollView(
          child: Padding(
            padding: PaddingApp.hor15,
            child: Column(
              children: [
                getHeight(20),
                const ContainerUpperBarSecurityQuestionScreen(),
                getHeight(20),
                const CardDisplayQuestion(),
                getHeight(20),
                const CardAnswerToSecurityQuestion(),
                ButtonSaveQuestion(userModel: userModel,),
                const ContainerSafetyTips(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
