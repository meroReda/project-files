import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/size_box_responsive.dart';
import 'package:smart_assistant_app/core/theme/colors_app.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import '../../core/assets/app_assets.dart';
import '../../view_model/splash/splash_logic.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      SplashLogic.goToRoutes(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorsApp.whiteColor,
        body: Stack(
          children: [
            Column(
              children: [
                getHeight(MediaQuery.of(context).size.height * .25),
                Center(
                  child: Image.asset(
                    Assets.assetsImagesLogoNoBackgroundpng,
                    height: MediaQuery.of(context).size.height * .35,
                  ),
                ),
                getHeight(20),
                Text(
                 'نرتّب دراستك معا',
                  style: TextStyleApp.font20Black
                      .copyWith(fontSize: 32),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
