import 'package:smart_assistant_app/core/assets/app_assets.dart';
import 'package:smart_assistant_app/model/onboarding_model.dart';

class OnboardingData {
  static List<OnboardingModel> onboardingModel = [
    OnboardingModel(image: Assets.assetsImagesOnboarding1, title: 'اختر موادك بذكاء', subTitle: 'نرشّح لك المواد المناسبة حسب خطتك\n الأكاديمية ونسب النجاح السابقة'),
    OnboardingModel(image: Assets.assetsImagesOnboarding2, title: 'ذاكر بكفاءة', subTitle: 'حوّل المحاضرات إلى ملخصات وبطاقات\n مراجعة تفاعلية بسهولة.'),
    OnboardingModel(image: Assets.assetsImagesOnboarding3, title: 'اختبر نفسك', subTitle: 'احصل على أسئلة قصيرة واختبارات \nذكية مبنية على ملفاتك'),
    
  ];
}