import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:smart_assistant_app/core/helpers/extension.dart';
import 'package:smart_assistant_app/core/router/router_views.dart';
import 'package:smart_assistant_app/core/server/local_storage.dart';
import '../../model/user_model.dart';

class SplashLogic {
  static Future<Null> goToRoutes(BuildContext context) async {
    return Future.delayed(const Duration(seconds: 2), () async {
    String ?user = await LocalStorage.getUser();
    if(user != null){
      Map<String,dynamic> userMap = json.decode(user);
      UserModel userModel         = UserModel.fromJson(userMap);
      if(userModel.securityQuestion == null) {
       context.pushAndRemoveUntil(RouterViews.securityQuestion, arguments: userModel);
      }
      else if(userModel.isTrue == false){
        context.pushAndRemoveUntil(RouterViews.completedCourses , arguments: userModel);
      }
      else{
        context.pushAndRemoveUntil(RouterViews.home , arguments: userModel);
      }
      return;
    }
    else{
      String?onBoarding = await LocalStorage.getOnboarding();
      if(onBoarding != null){
        context.pushAndRemoveUntil(RouterViews.login);
      }
      else{
        context.pushAndRemoveUntil(RouterViews.onboarding);
      }
    }
    });
  }
}
