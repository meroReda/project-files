abstract class SecurityQuestionState {}

class SecurityQuestionInitial extends SecurityQuestionState {}


class SecurityQuestionLoading extends SecurityQuestionState {}
class SecurityQuestionSelected extends SecurityQuestionState {
  final String question;
  final String answer;
  SecurityQuestionSelected(this.question, this.answer);
}


class SecurityQuestionError extends SecurityQuestionState {
  final String message;
  SecurityQuestionError(this.message);
}

class SecurityQuestionSucces extends SecurityQuestionState {
  final String message;
  SecurityQuestionSucces({required this.message});
}