import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/server/local_storage.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/repo/auth_repo.dart';
import 'package:smart_assistant_app/view_model/securityQuestion/security_question_state.dart';

class SecurityQuestionCubit extends Cubit<SecurityQuestionState> {
  SecurityQuestionCubit() : super(SecurityQuestionInitial());
  TextEditingController answerController = TextEditingController();
  final List<String> securityQuestionsAr = [
    'ما اسم مدينة ميلادك؟',
    'ما هو اسم أول مدرسة التحقت بها؟',
    'ما هو اسم والدتك؟',
    'ما هو اسم أفضل صديق في الطفولة؟',
    'ما هو طعامك المفضل؟'
  ];

  final List<String> stepList = [
    'اختر سؤالاً تعرف إجابته بوضوح',
    'تجنب الإجابات التي يمكن تخمينها بسهولة',
    'لا تشارك إجابتك مع أي شخص',
    'احفظ الإجابة في مكان آمن',
  ];
  int indexselectedQuestion = -1;
  String? selectedQuestion;
  String answer = '';

  void selectedQuestionIndex(int index) {
    if (index == indexselectedQuestion) {
      indexselectedQuestion = -1;
    } else {
      indexselectedQuestion = index;
    }
    emit(SecurityQuestionInitial());
  }

  void updateAnswer(String newAnswer) {
    answer = newAnswer;
    emit(SecurityQuestionInitial());
  }

  String getRequest(String userID) {
    return jsonEncode({
      "user_id": userID,
      "security_question": securityQuestionsAr[indexselectedQuestion],
      "security_answer": answerController.text
    });
  }

  Future<void> callRep(UserModel  user) async {
    final result = await  SignUpRepo.insertQuestion(getRequest(user.userID));
    emit(SecurityQuestionLoading());
    result.fold((message){
      emit(SecurityQuestionError(message));
    }, (message){
      LocalStorage.clearUser();
      user.securityQuestion = securityQuestionsAr[indexselectedQuestion];
      Map<String,dynamic> toJson = user.toJson();
      LocalStorage.saveUser(jsonEncode(toJson));
      emit(SecurityQuestionSucces(message: message));
    });
  }
}
