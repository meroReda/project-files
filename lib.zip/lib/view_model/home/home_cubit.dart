import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/dailog/show_dialog.dart';
import 'package:smart_assistant_app/model/course/current_course.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/repo/courses/delete_current_course_repo.dart';
import 'package:smart_assistant_app/view_model/home/home_state.dart';
import '../../core/helpers/cubit_app/connect_cubit.dart';
import '../../repo/courses/get_all_courses_for_user_repo.dart';

class HomeCubit extends Cubit<HomeState> {
  final ConnectivityCubit _connectivityCubit;
  HomeCubit(this._connectivityCubit) : super(HomeState());

  String getReqesutGetAllCoursesForUser(UserModel userModel) {
    return jsonEncode({'user_id': userModel.userID});
  }

  void getAllCouresesForUserInCubit(UserModel userModel) async {
    emit(state.copyWith(status: HomeStatus.loading));
    final resutlt = await GetAllCoursesForUserRepo.callAPI( getReqesutGetAllCoursesForUser(userModel));
    resutlt.fold((error) {
      emit(state.copyWith(status: HomeStatus.error, error: error));
    }, (coursesUser) {
      emit(state.copyWith(
        userModel: userModel,
        status: HomeStatus.success,
        coursesUser: coursesUser,
        error: null, // تأكد من مسح الخطأ عند النجاح
      ));
    });
  }




  void deleteCourseForUserInCubit( UserModel userModel, CurrentCourse courseId , BuildContext context , int unitCourse) async {
    int counter = state.coursesUser!.totalNumberOfCurrentUnits - unitCourse;
    if(counter < 12) {
      DialogHelper.errorMessage(context, 'إذا تم إسقاط ${courseId.name} يصبح لديك $counter وحدة واقل من عدد مسموح');
      return;
    }
    emit(state.copyWith(status: HomeStatus.loading));
    final request = jsonEncode({
      'user_id': userModel.userID,
      'courses': [
        int.parse(courseId.id)
      ]
    });
    final result = await DeleteCurrentCourseRepo.callAPI(request);
    result.fold((error) {
      emit(state.copyWith(status: HomeStatus.error, error: error));
    }, (message) {
      state.coursesUser!.currentCourse.remove(courseId);
      state.coursesUser!.totalNumberOfCurrentUnits -= unitCourse;
      emit(state.copyWith(status: HomeStatus.success, deleteMessage: message, ));
    });
  }
}
