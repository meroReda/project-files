import 'package:smart_assistant_app/model/course/courses_user.dart';
import 'package:smart_assistant_app/model/user_model.dart';

enum HomeStatus {
  initial,
  loading,
  success,
  error,
  noConnected,
}
class HomeState {
  final HomeStatus status;
  final String? error;
  final int selectedIndex;
  final CoursesUser? coursesUser;
  final String? deleteMessage;
  final UserModel? userModel;

  HomeState({
    this.status = HomeStatus.initial,
    this.error,
    this.userModel,
    this.deleteMessage,
    this.coursesUser,
    this.selectedIndex = 0,
  });

  HomeState copyWith({
    HomeStatus? status,
    String? error,
    CoursesUser? coursesUser,
    int? selectedIndex,
    String? deleteMessage,
    UserModel? userModel,
  }) {
    return HomeState(
      userModel: userModel??this.userModel,
      deleteMessage: deleteMessage,
      status: status ?? this.status,
      error: error ?? this.error,
      coursesUser: coursesUser ?? this.coursesUser,
      selectedIndex: selectedIndex ?? this.selectedIndex,
    );
  }
  // التحقق من الحالات
  bool get isLoading => status == HomeStatus.loading;
  bool get isSuccess => status == HomeStatus.success;
  bool get isError => status == HomeStatus.error;
  bool get isNoConnected => status == HomeStatus.noConnected;
  bool get isInitial => status == HomeStatus.initial;

  @override
  String toString() {
    return 'HomeState(status: $status, error: $error, selectedIndex: $selectedIndex, coursesUser: $coursesUser)';
  }
}