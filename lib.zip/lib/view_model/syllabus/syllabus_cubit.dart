import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:smart_assistant_app/core/server/end_point.dart';
import 'package:smart_assistant_app/model/syllabus_model.dart';
import 'package:smart_assistant_app/view_model/syllabus/syllabus_state.dart';

class SyllabusCubit extends Cubit<SyllabusState> {
  SyllabusCubit() : super(SyllabusInitial());
  TextEditingController fileNameController = TextEditingController();

  Future<void> fetchSyllabiForCourses(int userId, List<int> courseIds) async {
    if (courseIds.isEmpty) {
      emit(SyllabusInitial());
      return;
    }
    emit(SyllabusLoading());
    try {
      final response = await http.post(
        Uri.parse(EndPoint.apiGetSyllabus),
        body: jsonEncode({
          'user_id': userId,
          'course_ids': courseIds,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          // تحويل البيانات إلى قائمة من CourseWithSyllabiModel
          List<CourseWithSyllabiModel> coursesWithSyllabi = [];

          for (var courseData in data['data']) {
            // إنشاء قائمة المناهج لهذه المادة
            List<SyllabusModel> syllabi = [];
            for (var syllabusJson in courseData['syllabi']) {
              syllabusJson['user_id'] = userId;
              syllabusJson['course_id'] = courseData['course_id'];
              final syllabus = SyllabusModel.fromJson(syllabusJson);
              syllabi.add(syllabus);
            }

            // إنشاء كائن المادة مع المناهج
            final courseWithSyllabi = CourseWithSyllabiModel(
              courseId: int.parse(courseData['course_id'].toString()),
              courseName: courseData['course_name'] ?? '',
              courseCode: courseData['course_code'] ?? '',
              syllabi: syllabi,
            );
            coursesWithSyllabi.add(courseWithSyllabi);
          }

          emit(SyllabusLoaded(coursesWithSyllabi: coursesWithSyllabi));
        } else {
          emit(SyllabusError(data['message']));
        }
      } else {
        emit(SyllabusError('فشل في جلب البيانات: ${response.statusCode}'));
      }
    } catch (error) {
      emit(SyllabusError('خطأ في الاتصال: $error'));
    }
  }

  Future<void> uploadSyllabus({
  required String userId,
  required int courseId,
  required PlatformFile file,
  required String syllabusName,
  required  List<int> courseIds,
  String academicYear = '',
  String semester = 'الأول',
  String description = '',
  bool isPublic = false,
}) async {
  emit(SyllabusUploading());
  
  if (file.bytes == null) {
    emit(const SyllabusOperationError('ملف فارغ أو تالف'));
    return;
  }
  
  try {
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(EndPoint.apiUploadSyllabus),
    );

    request.fields['user_id'] = userId;
    request.fields['course_id'] = courseId.toString();
    request.fields['syllabus_name'] = syllabusName;
    request.fields['academic_year'] = academicYear.isNotEmpty ? academicYear : DateTime.now().year.toString();
    request.fields['semester'] = semester;
    if (description.isNotEmpty) {
      request.fields['description'] = description;
    }
    request.fields['is_public'] = isPublic ? '1' : '0';

    request.files.add(
      http.MultipartFile.fromBytes(
        'syllabus_file',
        file.bytes!,
        filename: file.name,
      ),
    );



    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    var jsonResponse = jsonDecode(response.body);

    
    if (response.statusCode == 200) {
      if (jsonResponse['status'] == 'success') {
        fetchSyllabiForCourses(int.parse(userId), courseIds);
        return;
      } else {
        emit(SyllabusOperationError(jsonResponse['message'] ?? 'فشل في رفع الملف'));
      }
    } else {
      emit(SyllabusOperationError('خطأ في الخادم: ${response.statusCode}'));
    }
  } catch (error) {
    emit(SyllabusOperationError('خطأ في الاتصال: $error'));
  }
}

  // حذف منهج
  Future<void> deleteSyllabus(int syllabusId, int courseId) async {
    emit(SyllabusDeleting());
    try {
      final response = await http.delete(
        Uri.parse(EndPoint.apiUploadSyllabus),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          emit(SyllabusDeleted(syllabusId: syllabusId, courseId: courseId));

          // تحديث القائمة الحالية
          if (state is SyllabusLoaded) {
            final currentState = state as SyllabusLoaded;
            final updatedCourses =
                currentState.coursesWithSyllabi.map((course) {
              if (course.courseId == courseId) {
                // إزالة المنهج المحذوف
                final updatedSyllabi = course.syllabi
                    .where((s) => s.syllabusId != syllabusId)
                    .toList();
                return CourseWithSyllabiModel(
                  courseId: course.courseId,
                  courseName: course.courseName,
                  courseCode: course.courseCode,
                  syllabi: updatedSyllabi,
                );
              }
              return course;
            }).toList();

            emit(SyllabusLoaded(coursesWithSyllabi: updatedCourses));
          }
        } else {
          emit(SyllabusOperationError(data['message']));
        }
      } else {
        emit(const  SyllabusOperationError('فشل في حذف المنهج'));
      }
    } catch (error) {
      emit(SyllabusOperationError('خطأ في الاتصال: $error'));
    }
  }

  
}
