import 'package:equatable/equatable.dart';

import '../../model/syllabus_model.dart';


enum SyllabusStatus{
  loading,
  success,
  error
}
abstract class SyllabusState extends Equatable {
  const SyllabusState();

  @override
  List<Object> get props => [];
}

class SyllabusInitial extends SyllabusState {}

class SyllabusLoading extends SyllabusState {}

class SyllabusLoaded extends SyllabusState {
  final List<CourseWithSyllabiModel> coursesWithSyllabi;

  const SyllabusLoaded({required this.coursesWithSyllabi});

  @override
  List<Object> get props => [coursesWithSyllabi];
}

class SyllabusError extends SyllabusState {
  final String message;

  const SyllabusError(this.message);

  @override
  List<Object> get props => [message];
}

class SyllabusUploading extends SyllabusState {}

class SyllabusUploaded extends SyllabusState {
  final SyllabusModel syllabus;

  const SyllabusUploaded(this.syllabus);

  @override
  List<Object> get props => [syllabus];
}

class SyllabusDeleting extends SyllabusState {}

class SyllabusDeleted extends SyllabusState {
  final int syllabusId;
  final int courseId;

  const SyllabusDeleted({required this.syllabusId, required this.courseId});

  @override
  List<Object> get props => [syllabusId, courseId];
}

class SyllabusOperationError extends SyllabusState {
  final String message;

  const SyllabusOperationError(this.message);

  @override
  List<Object> get props => [message];
}