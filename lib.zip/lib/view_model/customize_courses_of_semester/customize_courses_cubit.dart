import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/dailog/show_dialog.dart';
import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/customize_courses_of_semester/customize_courses_state.dart';
import '../../repo/courses/get_all_courses_for_user_repo.dart';
import '../../repo/courses/insert_current_courses_for_user_repo.dart';
import '../../repo/s.dart';

class CustomizeCoursesCubit extends Cubit<CustomizeCoursesState> {
  CustomizeCoursesCubit()
      : super(CustomizeCoursesState(
            selectedUnits: 0,
            isConfirmEnabled: false,
            status: CustomizeCoursesStatus.initial));

  String getReqesutGetAllCoursesForUser(UserModel userModel) {
    return jsonEncode({'user_id': userModel.userID});
  }

  void getAllCouresesForUserInCubit(UserModel userModel) async {
    emit(CustomizeCoursesState(
        status: CustomizeCoursesStatus.loadingCourses,
        selectedUnits: 0,
        isConfirmEnabled: false));
    final resutlt = await GetAllCoursesForUserRepo.callAPI(
        getReqesutGetAllCoursesForUser(userModel));
    resutlt.fold((error) {
      emit(CustomizeCoursesState(
          status: CustomizeCoursesStatus.error,
          selectedUnits: 0,
          isConfirmEnabled: false,
          errorMessage: error));
    }, (coursesUser) {
      emit(CustomizeCoursesState(
        coursesRequest: coursesUser.courseRequest,
        status: CustomizeCoursesStatus.succesGetCourese,
        selectedUnits: 0,
        isConfirmEnabled: false,
      ));
    });
  }

  static int _calculateSelectedUnits(List<CourseModel> courses) {
    return courses
        .where((course) => course.isSelected == true)
        .fold(0, (sum, course) => sum + int.parse(course.unit));
  }

  // تبديل حالة المادة
  void toggleCourseSelection(int index) {
    final currentCourses = List<CourseModel>.from(state.coursesRequest!);
    final courseToUpdate = currentCourses[index];
    final updatedCourse = CourseModel(
      isOpen: currentCourses[index].isOpen,
      level: currentCourses[index].level,
      optional: currentCourses[index].optional,
      sessonName: currentCourses[index].sessonName,
      request: currentCourses[index].request,
      name: courseToUpdate.name,
      code: courseToUpdate.code,
      id: courseToUpdate.id,
      unit: courseToUpdate.unit,
      doctorName: courseToUpdate.doctorName,
      isSelected: !courseToUpdate.isSelected,
    );
    currentCourses[index] = updatedCourse;

    final selectedUnits = _calculateSelectedUnits(currentCourses);
    final isConfirmEnabled = selectedUnits >= 12;

    emit(CustomizeCoursesState(
        coursesRequest: currentCourses,
        selectedUnits: selectedUnits,
        isConfirmEnabled: isConfirmEnabled,
        status: state.status));
  }

  // تأكيد الاختيار
  void confirmSelection() {
    if (state.selectedUnits <= 12) {
      emit(state.copyWith(isConfirmed: true));
      // هنا يمكنك إضافة منطق الحفظ أو الانتقال لشاشة أخرى
    }
  }

  String getRequstInsertCurrentCoursesForUser(UserModel userModel) {
    List<String> courseIds = state.coursesRequest!
        .where((course) => course.isSelected != false && course.id != null)
        .map((course) => course.id!)
        .toList();
    Map<String, dynamic> map = {
      "user_id": userModel.userID,
      "courses": courseIds,
      "academic_year": "2025-2026",
      "semester": "",
    };
    return jsonEncode(map);
  }

  Future<void> beforeRepo(BuildContext context, UserModel userModel) async {
    if (state.selectedUnits > 21) {
      DialogHelper.errorMessage(context, "تجاوزت 21 وحدة");
      return;
    }
    if (isClosed) return;
    emit(CustomizeCoursesState(
      selectedUnits: _calculateSelectedUnits(state.coursesRequest!),
      isConfirmEnabled: true,
      status: CustomizeCoursesStatus.loading,
      errorMessage: null,
      coursesRequest: state.coursesRequest!,
    ));
    String request = getRequstInsertCurrentCoursesForUser(userModel);

    final result = await InsertCurrentCoursesForUserRepo.callAPI(request);
    if (isClosed) return;
    result.fold((error) {
      if (!isClosed) {
        emit(CustomizeCoursesState(
          coursesRequest: state.coursesRequest!,
          selectedUnits: _calculateSelectedUnits(state.coursesRequest!),
          isConfirmEnabled: true,
          status: CustomizeCoursesStatus.error,
          errorMessage: error,
        ));
      }
    }, (message) {
      if (!isClosed) {
        emit(CustomizeCoursesState(
          selectedUnits: _calculateSelectedUnits(state.coursesRequest!),
          isConfirmEnabled: true,
          status: CustomizeCoursesStatus.success,
          errorMessage: null,
          coursesRequest: state.coursesRequest!,
        ));
      }
    });
  }

  Future<void> insertCourse(String userId) async {
    List<String> courseIds = state.optionModel![state.selectedOpt!].courses
        .where((course) => course.id != null)
        .map((course) => course.id!)
        .toList();
    Map<String, dynamic> map = {
      "user_id": userId,
      "courses": courseIds,
      "academic_year": "2025-2026",
      "semester": "",
    };

    final result =
        await InsertCurrentCoursesForUserRepo.callAPI(jsonEncode(map));
    if (isClosed) return;
    result.fold((error) {
      if (!isClosed) {
        emit(state.copyWith(
            errorMessage: error, status: CustomizeCoursesStatus.error));
      }
    }, (message) {
      emit(state.copyWith(status: CustomizeCoursesStatus.success));
    });
  }

  Future<void> fetch(List<CourseModel> courses, String userId) async {
    emit(state.copyWith(status: CustomizeCoursesStatus.loadingCoursesUser));
    try {
      final selectedCourseIds = courses
          .where((course) => course.id != null && course.id!.isNotEmpty)
          .map((course) => course.id!)
          .toList();

      // التحقق من أن لدينا على الأقل course واحد صالح
      if (selectedCourseIds.isEmpty) {
        emit(state.copyWith(
            status: CustomizeCoursesStatus.error,
            errorMessage: "No valid course IDs found"));
        return;
      }

      final result =
          await GetScheduleOptionsRep.callAPI(selectedCourseIds, userId);

      result.fold(
        (error) {
          emit(state.copyWith(
              status: CustomizeCoursesStatus.error,
              errorMessage: error.toString()));
        },
        (options) {
          emit(state.copyWith(
              status: CustomizeCoursesStatus.succesGetCoursesUser,
              optionModel: options));
        },
      );
    } catch (e) {
      emit(state.copyWith(
          status: CustomizeCoursesStatus.error, errorMessage: e.toString()));
    }
  }

  void changeSelectedOp(int index) {
    if (state.selectedOpt == index) {
      emit(state.copyWith(selectedOpt: -1, isConfirmEnabled: false));
    } else {
      emit(state.copyWith(selectedOpt: index, isConfirmEnabled: true));
    }
  }

  void initialState() {
    emit(state.copyWith(status: CustomizeCoursesStatus.initial));
  }

  void changeSelect(int index) {
    if ((index == 0 && state.status == CustomizeCoursesStatus.systemSelect) ||
        (index == 1 && state.status == CustomizeCoursesStatus.customSelect)) {
      emit(state.copyWith(
        status: CustomizeCoursesStatus.initial,
      ));
    } else {
      // وإلا نحدد الحالة الجديدة
      final newStatus = index == 0
          ? CustomizeCoursesStatus.systemSelect
          : CustomizeCoursesStatus.customSelect;
      emit(state.copyWith(
        status: newStatus,
      ));
    }
  }
}
