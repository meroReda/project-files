import 'package:flutter/material.dart';

class CourseSelectionMode {
  final Color backgroundColor;
  final IconData icon;
  final String title;
  final String subtitle;
  final Color colorIcon;
  final List<ModeOption> options;
  bool isSelected;

  CourseSelectionMode({
    required this.backgroundColor,
    required this.icon,

    this.isSelected = false,
    required this.colorIcon,
    required this.title,
    required this.subtitle,
    required this.options,
  });
}

class ModeOption {
  final String text;
  final Color color;

  ModeOption({
    required this.text,
    required this.color,
  });

  ModeOption copyWith({bool? isSelected}) {
    return ModeOption(
      text: text,
      color: color,
    );
  }
}

final List<CourseSelectionMode> courseSelectionModes = [
  CourseSelectionMode(
    colorIcon: Colors.blue,
    backgroundColor: const Color(0xFFe7e9fe),
    icon: Icons.auto_awesome,
    title: "مواد موصى بها تلقائياً",
    subtitle: "دع النظام يختار لك أفضل المواد بناءً على تقدمك الأكاديمي واهتماماتك",
    options: [
      ModeOption(text: "ذكي", color: const Color(0xFF2196F3)),
      ModeOption(text: "سريع", color: const Color(0xFF9C27B0)),
      ModeOption(text: "موصى به", color: const Color(0xFF4CAF50)),
    ],
  ),
  CourseSelectionMode(
    colorIcon: Colors.orange,
    backgroundColor: const Color(0xFFFEF7E6),
    icon: Icons.tune,
    title: "اختبار مخصص",
    subtitle: "اختر موادك بنفسك من قائمة المواد المتاحة حسب تفضيلاتك الشخصية",
    options: [
      ModeOption(text: "مرن", color: const Color(0xFFFF9800)),
      ModeOption(text: "شخصي", color: const Color(0xFFF44336)),
      ModeOption(text: "دقيق", color: const Color(0xFF3F51B5)),
    ],
  ),
];
