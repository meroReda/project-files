import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/option_model.dart';

enum CustomizeCoursesStatus {
  initial,    // الحالة الأولية (لم يتم تحميل المواد بعد)
  loading,    // جاري تحميل المواد
  success,    // تم تحميل المواد بنجاح
  error,      // حدث خطأ في تحميل المواد
  customSelect, 
  systemSelect,
  succesGetCourese,
  succesGetCoursesUser,
  loadingCourses,
  loadingCoursesUser,
  
}

class CustomizeCoursesState {
  final List<CourseModel>? coursesRequest;
  final List<CourseModel>?selectedCourses;
  final int selectedUnits;
  final bool isConfirmEnabled;
  final bool isConfirmed;
  final int? selectedOpt;
  final CustomizeCoursesStatus status;
  final String? errorMessage;
  final List<OptionModel>? optionModel;

  CustomizeCoursesState({
    this.coursesRequest,
    this.optionModel,
    this.selectedOpt,
    this.selectedCourses,
    required this.selectedUnits,
    required this.isConfirmEnabled,
    this.isConfirmed = false,
    this.status = CustomizeCoursesStatus.initial,
    this.errorMessage,
  });

  CustomizeCoursesState copyWith({
    int? selectedUnits,
    bool? isConfirmEnabled,
    bool? isConfirmed,
    CustomizeCoursesStatus? status,
    String? errorMessage,
    List<CourseModel>? courseRequest,
    List<OptionModel>?optionModel,
    List<CourseModel>?selectedCourses,
    int ? selectedOpt
  }) {
    return CustomizeCoursesState(
      selectedOpt: selectedOpt?? this.selectedOpt,
      optionModel: optionModel??this.optionModel,
      selectedCourses: selectedCourses?? this.selectedCourses,
      coursesRequest: coursesRequest?? coursesRequest,
      selectedUnits: selectedUnits ?? this.selectedUnits,
      isConfirmEnabled: isConfirmEnabled ?? this.isConfirmEnabled,
      isConfirmed: isConfirmed ?? this.isConfirmed,
      status: status ?? this.status,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}