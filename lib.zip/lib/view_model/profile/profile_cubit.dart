import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/repo/auth_repo.dart';
import 'package:smart_assistant_app/view_model/profile/profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit() : super(ProfileState());
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final currentPasswordController = TextEditingController();
  String password = '';
  final List<String> conditions = [
    "8 أحرف على الأقل",
    "حرف كبير واحد على الأقل (A-Z)",
    "حرف صغير واحد على الأقل (a-z)",
    "رقم واحد على الأقل (0-9)",
  ];

  // Toggle editing mode
  void toggleEditing() {
    emit(state.editing(!state.isEditing));
  }

  void getUser(UserModel userModel) async {
    password = userModel.password;
    emit(state.copyWith(status: ProfileStatus.initial, userModel: userModel));
  }

  void validatePassword(String password) {
    // قائمة بالشروط ونتائجها
    List<bool> newConditions = [
      password.length >= 8, // 8
      password.contains(RegExp(r'[A-Z]')),
      password.contains(RegExp(r'[a-z]')),
      password.contains(RegExp(r'[0-9]')),
    ];
    // تحديث الحالة بالقائمة الجديدة
    emit(state.updateList(newConditions));
  }

  void update() async {
  
    if (!formKey.currentState!.validate()) {
    } else {
      emit(state.copyWith(status: ProfileStatus.loading));
      final result = await SignUpRepo.updateUser(jsonEncode({
        "user_id": state.userModel!.userID,
        "password": newPasswordController.text
      }));
      result.fold((error) {
        emit(state.copyWith(status: ProfileStatus.error, error: error));
      }, (user) {
        confirmPasswordController.text = currentPasswordController.text =  newPasswordController.text = '';
        emit(state.copyWith(status: ProfileStatus.success, userModel: user));
      });
    }
  }

  void resetPasswordFields() {
    newPasswordController.text = '';
    confirmPasswordController.text = '';
    currentPasswordController.text = '';
    
    emit(state.copyWith(list: [false, false, false, false]));
  }

  // Clear error
  void clearError() {
    if (state.status == ProfileStatus.error) {
      emit(state.copyWith(error: null, status: ProfileStatus.success));
    }
  }
}
