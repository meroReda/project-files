import '../../model/user_model.dart';

enum ProfileStatus {
  initial,
  loading,
  success,
  error,
  noConnected,
  updating,
}

class ProfileState {
  final UserModel? userModel;
  final String? error;
  final ProfileStatus status;
  final bool isEditing;
  final List<bool> list;
  final Map<String, dynamic>? updatedFields;

  ProfileState({
    this.userModel,
    this.error,
    List<bool>? list, // جعلها اختيارية
    this.status = ProfileStatus.initial,
    this.isEditing = false,
    this.updatedFields,
  }) : list = list ?? [false, false, false, false]; // تعيين القيمة الافتراضية

  // Methods for copying and updating state
  ProfileState copyWith({
    UserModel? userModel,
    String? error,
    ProfileStatus? status,
    bool? isEditing,
    List<bool>? list, // إضافة list هنا
    Map<String, dynamic>? updatedFields,
  }) {
    return ProfileState(
      userModel: userModel ?? this.userModel,
      error: error ?? this.error,
      status: status ?? this.status,
      isEditing: isEditing ?? this.isEditing,
      list: list ?? this.list, // نسخ القائمة الحالية إذا لم يتم توفير جديدة
      updatedFields: updatedFields ?? this.updatedFields,
    );
  }

  // Initial state
  static ProfileState initial() {
    return ProfileState(
      status: ProfileStatus.initial,
      isEditing: false,
      list: [false, false, false, false], // كلها false
    );
  }

  // Loading state
  ProfileState loading() {
    return copyWith(
      status: ProfileStatus.loading,
      error: null,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // Success state
  ProfileState success({UserModel? user}) {
    return copyWith(
      status: ProfileStatus.success,
      userModel: user ?? userModel,
      error: null,
      isEditing: false,
      updatedFields: null,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // Error state
  ProfileState errorState(String error) {
    return copyWith(
      status: ProfileStatus.error,
      error: error,
      isEditing: false,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // No connection state
  ProfileState noConnected() {
    return copyWith(
      status: ProfileStatus.noConnected,
      error: 'لا يوجد اتصال بالإنترنت',
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // Updating state
  ProfileState updating({Map<String, dynamic>? updatedFields}) {
    return copyWith(
      status: ProfileStatus.updating,
      updatedFields: updatedFields,
      isEditing: true,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // Editing state
  ProfileState editing(bool isEditing) {
    return copyWith(
      isEditing: isEditing,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // Update user fields locally (before sending to API)
  ProfileState updateUserField({String? fullName, String? password, String? yearOfJoining}) {
    final newUser = userModel?.copyWith(
      fullName: fullName ?? userModel?.fullName,
      password: password ?? userModel?.password,
      yearOfJoining: yearOfJoining ?? userModel?.yearOfJoining,
    );
    
    return copyWith(
      userModel: newUser,
      list: [false, false, false, false], // إعادة تعيين القائمة
    );
  }

  // دالة خاصة لتحديث القائمة
  ProfileState updateList(List<bool> newList) {
    return copyWith(list: newList);
  }

  // دالة لتحديث عنصر معين في القائمة
  ProfileState updateListItem(int index, bool value) {
    if (index >= 0 && index < list.length) {
      final newList = List<bool>.from(list);
      newList[index] = value;
      return copyWith(list: newList);
    }
    return this;
  }

  // دالة لإعادة تعيين القائمة إلى جميعها false
  ProfileState resetList() {
    return copyWith(list: [false, false, false, false]);
  }

  // دالة لفحص إذا كانت كل العناصر true
  bool get isAllListTrue {
    return list.every((element) => element == true);
  }

  // دالة لفحص إذا كانت كل العناصر false
  bool get isAllListFalse {
    return list.every((element) => element == false);
  }

  @override
  String toString() {
    return 'ProfileState(status: $status, isEditing: $isEditing, error: $error, list: $list)';
  }
}