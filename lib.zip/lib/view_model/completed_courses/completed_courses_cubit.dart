// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/core/helpers/dailog/show_dialog.dart';
import 'package:smart_assistant_app/core/theme/text_style_app.dart';
import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/repo/courses/get_all_course_rep.dart';
import 'package:smart_assistant_app/view_model/completed_courses/completed_courses_state.dart';
import '../../core/helpers/cubit_app/connect_cubit.dart';
import '../../repo/courses/get_courses_insert_user_repo.dart';
class CompletedCoursesCubit extends Cubit<CompletedCoursesState> {
  final ConnectivityCubit _connectivityCubit;
  CompletedCoursesCubit(this._connectivityCubit)
      : super(CompletedCoursesState());

  StreamSubscription? _connectivitySubscription;

  @override
  Future<void> close() {
    _connectivitySubscription?.cancel();
    return super.close();
  }
  
   String getCurrentSeasonName() {
    return getNameSeason(state.selectedSeasonIndex);
  }

  List<CourseModel> getCoursesForCurrentSeason() {
    if (state.allCourses?.isEmpty ?? true) return [];
    final seasonName = getCurrentSeasonName();
    return CourseModel.filterCoursesBySession(state.allCourses!, seasonName);
  }

  void _applyFilters() {
    if (state.allCourses?.isEmpty ?? true) return;
    final filtered = getCoursesForCurrentSeason();
    emit(state.copyWith(filteredCourses: filtered));
  }

  void changeSeason(int index) {
    emit(state.copyWith(selectedSeasonIndex: index));
    _applyFilters();
  }


  static String getNameSeason(int index) {
    switch (index) {
      case 0:
        return 'الفصل الأول';
      case 1:
        return 'الفصل الثاني';
      case 2:
        return 'الفصل الثالث';
      case 3:
        return 'الفصل الرابع';
      case 4:
        return 'الفصل الخامس';
      case 5:
        return 'الفصل السادس';
      case 6:
        return 'الفصل السابع';
      case 7:
        return 'الفصل الثامن';
      default:
        return 'أختيارية';
    }
  }
  
  List<String> listAllSeason = [
    'الفصل الأول',
    'الفصل الثاني',
    'الفصل الثالث',
    'الفصل الرابع',
    'الفصل الخامس',
    'الفصل السادس',
    'الفصل السابع',
    'الفصل الثامن',
    'أختيارية',
  ];

 

  

  void _safeEmit(CompletedCoursesState newState) {
    if (!isClosed) {
      emit(newState);
    }
  }

  

  void toggleCourseSelection(CourseModel course) {
    final List<CourseModel> selectedCourses =
        List.from(state.selectedCourses ?? []);
    final List<CourseModel> filteredCourses =
        List.from(state.filteredCourses ?? []);

    if (selectedCourses.contains(course)) {
      selectedCourses.remove(course);
    } else {
      selectedCourses.add(course);
    }

    if (!isClosed) {
      emit(state.copyWith(
        selectedCourses: selectedCourses,
        filteredCourses: filteredCourses,
      ));
    }
  }

  Future<void> beforeRepo() async {
    _connectivitySubscription?.cancel();
    _connectivitySubscription =
        _connectivityCubit.stream.listen((connectivityState) {
      if (connectivityState is ConnectivityDisconnected) {
        _safeEmit(state.copyWith(status: CompletedCoursesStatus.noConnected));
      }
    });
    final connectivityState = _connectivityCubit.state;
    if (connectivityState is ConnectivityDisconnected) {
      _safeEmit(CompletedCoursesState(
        status: CompletedCoursesStatus.noConnected,
        selectedCourses: [],
        filteredCourses: [],
        allCourses: [],
      ));
      return;
    }
    emit(CompletedCoursesState(status: CompletedCoursesStatus.loading));
    final result = await GetAllCourseRep.callAPI();
    result.fold(
      (error) {
        _safeEmit(state.copyWith(
          status: CompletedCoursesStatus.error,
          error: error,
        ));
      },
      (list) {
        final allCourses = list;
        final filtered = _filterCoursesBySeason(allCourses, state.selectedSeasonIndex);
        _safeEmit(state.copyWith(
          status: CompletedCoursesStatus.success,
          allCourses: allCourses,
          filteredCourses: filtered,
          selectedCourses:  [],
        ));
      },
    );
  }

  List<CourseModel> _filterCoursesBySeason(
      List<CourseModel> courses, int seasonIndex) {
    if (courses.isEmpty) return [];
    final seasonName = getNameSeason(seasonIndex);
    return CourseModel.filterCoursesBySession(courses, seasonName);
  }

  void resetFilters() {
    emit(state.copyWith(
      selectedSeasonIndex: 0,
      filteredCourses: _filterCoursesBySeason(state.allCourses ?? [], 0),
      selectedCourses: [],
    ));
  }

  String getRequstInsertCoursesForUser(UserModel userModel) {
    List<String> courseIds = state.selectedCourses?.map((course) => course.id!).toList() ?? [];
    Map<String, dynamic> map = {
      "user_id": userModel.userID,
      "courses": courseIds
    };
    return jsonEncode(map);
  }

  void inserCourses(UserModel userModel, BuildContext context) async {
     _connectivitySubscription?.cancel();
    _connectivitySubscription =
        _connectivityCubit.stream.listen((connectivityState) {
      if (connectivityState is ConnectivityDisconnected) {
        _safeEmit(state.copyWith(status: CompletedCoursesStatus.noConnected));
      }
    });
    final connectivityState = _connectivityCubit.state;
    if (connectivityState is ConnectivityDisconnected) {
      _safeEmit(CompletedCoursesState(
        status: CompletedCoursesStatus.noConnected,
        selectedCourses: [],
        filteredCourses: [],
        allCourses: [],
      ));
      return;
    }

    if(state.selectedCourses!.isEmpty){
      DialogHelper.showMessage(context, 'اختر مادة على الأقل', Colors.red, TextStyleApp.font10White);
      return;
    }
    emit(CompletedCoursesState(
        status: CompletedCoursesStatus.loading,
        selectedCourses: state.selectedCourses,
        filteredCourses: state.filteredCourses,
        allCourses: state.allCourses,
        selectedSeasonIndex: state.selectedSeasonIndex));
    String request = getRequstInsertCoursesForUser(userModel);
    final result = await GetCoursesInsertUserRepo.callAPI(request);
    result.fold((error) {
      emit(CompletedCoursesState(
          status: CompletedCoursesStatus.error,
          selectedCourses: state.selectedCourses,
          filteredCourses: [],
          error: error));
          
    }, (list) {
       emit(CompletedCoursesState( status: CompletedCoursesStatus.insertCourses));
    });
  }
}
// المستخدم غير موجود