import 'package:smart_assistant_app/model/course_model.dart';

enum CompletedCoursesStatus {
  initial,  
  loading,   
  success,   
  error,     
  noConnected,
  insertCourses,
}

class CompletedCoursesState {
  final List<CourseModel>? selectedCourses;
  final List<CourseModel>? filteredCourses;
  final List<CourseModel>? allCourses;
  final int selectedSeasonIndex;
  final String? error;
  final CompletedCoursesStatus status;
  
  CompletedCoursesState({
    this.selectedCourses,
    this.filteredCourses,
    this.allCourses,
    this.error,
    this.status = CompletedCoursesStatus.initial,
    this.selectedSeasonIndex = 0,
  });

  CompletedCoursesState copyWith({
    List<CourseModel>? selectedCourses,
    List<CourseModel>? filteredCourses,
    List<CourseModel>? allCourses,
    int? selectedSeasonIndex,
    String? error,
    CompletedCoursesStatus? status,
  }) {
    return CompletedCoursesState(
      selectedCourses: selectedCourses ?? this.selectedCourses,
      filteredCourses: filteredCourses ?? this.filteredCourses,
      allCourses: allCourses ?? this.allCourses,
      selectedSeasonIndex: selectedSeasonIndex ?? this.selectedSeasonIndex,
      error: error ?? this.error,
      status: status ?? this.status,
    );
  }
}