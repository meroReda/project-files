

import '../../../model/user_model.dart';

enum LoginStatus{
  initial,
  loading,
  success,
  error,
  noConnected,
}



class LoginState{
  final UserModel? userModel;
  final String? error;
  final LoginStatus status;
  LoginState({this.userModel, this.error,  this.status = LoginStatus.initial});
}

