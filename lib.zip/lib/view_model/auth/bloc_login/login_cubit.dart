import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/view_model/auth/bloc_login/login_state.dart';
import '../../../core/helpers/cubit_app/connect_cubit.dart';
import '../../../repo/auth_repo.dart';

class LoginCubit extends Cubit<LoginState> {
  final ConnectivityCubit _connectivityCubit;
  LoginCubit(this._connectivityCubit) : super(LoginState());
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

   void beforeRep(String loginRequest) async {
     final connectivityState = _connectivityCubit.state;
    if (connectivityState is ConnectivityDisconnected) {
      emit(LoginState(status: LoginStatus.noConnected, error: null));
      return;
    }
    emit(LoginState(status: LoginStatus.loading , error: null));
    final result = await LoginRepo.callAPI(loginRequest);
    result.fold((error) {
      emit(LoginState(status: LoginStatus.error , error: error));
    }, (userModel) {
      emit(LoginState(error: null , status: LoginStatus.success , userModel: userModel ));
    });
  }
}
