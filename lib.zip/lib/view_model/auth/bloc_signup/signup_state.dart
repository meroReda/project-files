import '../../../model/user_model.dart';

enum SignupStatus {
  initial,
  loading,
  success,
  error,
  noConnected,
}

class SignupState {
  final UserModel? userModel;
  final String? error;
  final SignupStatus? status;
  SignupState({this.userModel, this.error, this.status});
}
