import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/view_model/auth/bloc_signup/signup_state.dart';
import '../../../core/helpers/cubit_app/connect_cubit.dart';
import '../../../repo/auth_repo.dart';

class SignupCubit extends Cubit<SignupState> {
  final ConnectivityCubit _connectivityCubit;
  SignupCubit(this._connectivityCubit) : super(SignupState(status: SignupStatus.initial));
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController rePasswordController = TextEditingController();
  TextEditingController fullNameController = TextEditingController();
  TextEditingController yearController     = TextEditingController();
  
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

   void beforeRep(String signupRequest) async {
    final connectivityState = _connectivityCubit.state;
    if (connectivityState is ConnectivityDisconnected) {
      emit(SignupState(status: SignupStatus.noConnected));
      return;
    }
    emit(SignupState(status: SignupStatus.loading));
    final result = await SignUpRepo.callAPI(signupRequest);
    result.fold((error) {
      emit(SignupState(status: SignupStatus.error , error: error));
    }, (userModel) {
      emit(SignupState(status: SignupStatus.success , userModel: userModel , error: null));
    });
  }
}
