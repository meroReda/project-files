import 'dart:convert';

class LoginRequest {
  final String email;
  final String password;
  LoginRequest({required this.email, required this.password});
  String toJson(){
        
        Map<String,String> myMap = {
          "email" : email,
          "password" : password,
     

        };
        return jsonEncode(myMap);
  }
}


class SignUpRequest {
  final String email;
  final String password;
  final String fullName;
  final String yearOfJoining;
  SignUpRequest({required this.email, required this.password , required this.fullName , required this.yearOfJoining});
  String toJson(){
        
        Map<String,String> myMap = {
          "email" : email,
          "password" : password,
          "fullName" : fullName,
          "YearOfJoining" : yearOfJoining,
        };
        return jsonEncode(myMap);
  }
}

