import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/view_model/auth/auth_request.dart';
import 'package:smart_assistant_app/view_model/auth/bloc_login/login_cubit.dart';
import 'package:smart_assistant_app/view_model/auth/bloc_signup/signup_cubit.dart';
class AuthLogic {
  static buttonLogin(BuildContext context) {
    final loginCubit = context.read<LoginCubit>();
    if (!loginCubit.formKey.currentState!.validate()) {}
    else {
      LoginRequest loginRequest = LoginRequest(email: loginCubit.emailController.text, password: loginCubit.passwordController.text);
      loginCubit.beforeRep(loginRequest.toJson());
    }
  }


  static buttonSignUp(BuildContext context) {
    final signupCubit = context.read<SignupCubit>();
    
    if (!signupCubit.formKey.currentState!.validate()) {}
    else  {
      SignUpRequest signUpRequest =  SignUpRequest(email:  signupCubit.emailController.text, password:  signupCubit.passwordController.text , fullName:  signupCubit.fullNameController.text , yearOfJoining: signupCubit.yearController.text);
      signupCubit.beforeRep(signUpRequest.toJson());
    }
  }
}
