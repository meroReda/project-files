// lib/features/recommended_courses/presentation/cubit/recommended_courses_state.dart

import 'package:smart_assistant_app/model/course_model.dart';
import 'package:smart_assistant_app/model/user_model.dart';

enum RecommendedCoursesStatus {
  initial,
  loading,
  success,
  error,
  noConnected,
}

class RecommendedCoursesState {
  final RecommendedCoursesStatus status;
  final String? error;
  final UserModel? userModel;
  final List<CourseModel>? recommendedCourses;
  final List<CourseModel>? availableCourses;
  final int? totalAvailableUnits;
  final int? totalCurrentUnits;
  final bool isLoadingMore;
  final bool hasReachedMax;

  RecommendedCoursesState({
    this.status = RecommendedCoursesStatus.initial,
    this.error,
    this.userModel,
    this.recommendedCourses,
    this.availableCourses,
    this.totalAvailableUnits,
    this.totalCurrentUnits,
    this.isLoadingMore = false,
    this.hasReachedMax = false,
  });

  RecommendedCoursesState copyWith({
    RecommendedCoursesStatus? status,
    String? error,
    UserModel? userModel,
    List<CourseModel>? recommendedCourses,
    List<CourseModel>? availableCourses,
    int? totalAvailableUnits,
    int? totalCurrentUnits,
    bool? isLoadingMore,
    bool? hasReachedMax,
  }) {
    return RecommendedCoursesState(
      status: status ?? this.status,
      error: error ?? this.error,
      userModel: userModel ?? this.userModel,
      recommendedCourses: recommendedCourses ?? this.recommendedCourses,
      availableCourses: availableCourses ?? this.availableCourses,
      totalAvailableUnits: totalAvailableUnits ?? this.totalAvailableUnits,
      totalCurrentUnits: totalCurrentUnits ?? this.totalCurrentUnits,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      hasReachedMax: hasReachedMax ?? this.hasReachedMax,
    );
  }

  // التحقق من الحالات
  bool get isInitial => status == RecommendedCoursesStatus.initial;
  bool get isLoading => status == RecommendedCoursesStatus.loading;
  bool get isSuccess => status == RecommendedCoursesStatus.success;
  bool get isError => status == RecommendedCoursesStatus.error;
  bool get isNoConnected => status == RecommendedCoursesStatus.noConnected;

  @override
  String toString() {
    return 'RecommendedCoursesState('
        'status: $status, '
        'error: $error, '
        'recommendedCourses: ${recommendedCourses?.length}, '
        'availableCourses: ${availableCourses?.length}, '
        'totalAvailableUnits: $totalAvailableUnits, '
        'totalCurrentUnits: $totalCurrentUnits'
        ')';
  }
}