import 'dart:async';
import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_assistant_app/model/user_model.dart';
import 'package:smart_assistant_app/view_model/recommended_courses/recommended_courses_state%20.dart';
import '../../model/course_model.dart';
import '../../repo/courses/get_all_courses_for_user_repo.dart';

class RecommendedCoursesCubit extends Cubit<RecommendedCoursesState> {
  RecommendedCoursesCubit({required UserModel userModel}):super(RecommendedCoursesState(userModel: userModel));

  // جلب المواد المقترحة
  Future<void> getRecommendedCourses() async {
    try {
      emit(state.copyWith(status: RecommendedCoursesStatus.loading));
      if (state.userModel == null) {
        emit(state.copyWith(
          status: RecommendedCoursesStatus.error,
          error: 'يجب تسجيل الدخول أولاً',
        ));
        return;
      }
      final request = jsonEncode({
        'user_id': state.userModel!.userID,
        'type': 'recommended', // إضافة نوع الطلب إذا كان هناك endpoint خاص
      });

      final result = await GetAllCoursesForUserRepo.callAPI(request);

      result.fold(
        (error) {
          if (error.contains('لا يوجد إتصال بالإنترنت')) {
            emit(state.copyWith(
              status: RecommendedCoursesStatus.noConnected,
              error: error,
            ));
          } else {
            emit(state.copyWith(
              status: RecommendedCoursesStatus.error,
              error: error,
            ));
          }
        },
        (coursesUser) {
          final recommendedCourses = coursesUser.courseRequest;
          final availableCourses = coursesUser.otherCourses;
          emit(state.copyWith(
            status: RecommendedCoursesStatus.success,
            recommendedCourses: recommendedCourses,
            availableCourses: availableCourses,
            totalAvailableUnits: coursesUser.totalNumberOfAvailableUnits,
            totalCurrentUnits: coursesUser.totalNumberOfCurrentUnits,
          ));
        },
      );
    } catch (e) {
      emit(state.copyWith(
        status: RecommendedCoursesStatus.error,
        error: 'حدث خطأ غير متوقع: ${e.toString()}',
      ));
    }
  }



  Future<void> addRecommendedCourse(CourseModel course) async {
    try {
      emit(state.copyWith(isLoadingMore: true));
      final updatedRecommended = List<CourseModel>.from(
          state.recommendedCourses ?? [])
        ..removeWhere((c) => c.id == course.id);

      final updatedAvailable = List<CourseModel>.from(
          state.availableCourses ?? [])
        ..add(course);

      emit(state.copyWith(
        recommendedCourses: updatedRecommended,
        availableCourses: updatedAvailable,
        isLoadingMore: false,
      ));

      // يمكنك إضافة رسالة نجاح هنا
    } catch (e) {
      emit(state.copyWith(
        isLoadingMore: false,
        error: 'فشل إضافة المادة: ${e.toString()}',
      ));
    }
  }

  // تحديث معلومات المستخدم
  void updateUserModel(UserModel userModel) {
    emit(state.copyWith(userModel: userModel));
  }

  // إعادة تحميل البيانات
  Future<void> refreshData() async {
    await getRecommendedCourses();
  }

  // مسح الأخطاء
  void clearError() {
    if (state.isError) {
      emit(state.copyWith(error: null));
    }
  }
}