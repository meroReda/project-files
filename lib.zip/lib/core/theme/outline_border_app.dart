

import 'package:flutter/material.dart';

OutlineInputBorder whiteBorderRaduis25 = OutlineInputBorder(
   borderRadius: BorderRadius.circular(15),
   borderSide: const BorderSide(width: 0.5 , color: Color.fromARGB(255, 6, 118, 209))
);