import 'package:flutter/material.dart';

ThemeData themeData() {
  return ThemeData(
   fontFamily: 'tajawal',
   scaffoldBackgroundColor: Colors.white
  );
}
